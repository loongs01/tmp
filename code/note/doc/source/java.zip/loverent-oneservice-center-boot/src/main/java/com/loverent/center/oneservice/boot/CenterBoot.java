package com.loverent.center.oneservice.boot;

import com.loverent.framework.boot.AbstractBoot;
import com.loverent.framework.boot.BaseBootApplication;
import com.loverent.framework.boot.LoveRentSystem;
import com.loverent.framework.filter.SkyWalkingRequestFilter;
import org.mybatis.spring.annotation.MapperScan;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Import;

/**
 * 中心启动类示例
 *
 * @author yu.ce@foxmail.com
 * @since 1.0.0
 * @date  2019-09-04 16:58
 */
@SpringBootApplication
@EnableDiscoveryClient
@ComponentScan({"com.loverent"})
@MapperScan("com.loverent.center.oneservice.biz.dao.mapper")
@Import(SkyWalkingRequestFilter.class)
public class CenterBoot extends BaseBootApplication {
	public static void main(String[] args) throws Exception {
		new AbstractBoot(CenterBoot.class , args) {
			@Override
			public void execute() {
				LoveRentSystem.init();
			}
		}.run();
	}
}
