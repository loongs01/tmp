package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessClassReqDto implements Serializable {

    @NotEmpty(message = "指标统计开始日期 不能为空")
    @ApiModelProperty(value="指标统计开始日期")
    private Date statStartDate;

    @NotEmpty(message = "指标统计结束日期 不能为空")
    @ApiModelProperty(value="指标统计结束日期")
    private Date statEndDate;

    @NotEmpty(message = "merchantCode 不能为空")
    @ApiModelProperty(value="merchantCode")
    private String  merchantCode;

    @ApiModelProperty(value="运营品类编码")
    private String  optClassCode;

    @ApiModelProperty(value="运营品类名称")
    private String  optClassName;
}
