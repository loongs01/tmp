package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.math.BigInteger;
import java.util.List;


//瀑布流数据
@Data
public class GoodsFirstPageWaterfallListReqDto implements Serializable {

    @NotEmpty(message = "渠道 不能为空")
    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    @NotEmpty(message = "排名值不能为空")
    @ApiModelProperty(value="排名值")
    private Integer  listRk;

    @ApiModelProperty(value="商品code集合")
    private List<String> goodsCode;

}
