package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * top50请求参数
 * @author stogel
 */
@Data
public class BigDataRankGoodsTop50BodyReqDto {

    @ApiModelProperty(value="一级分类页ID")
    private Long  catePageLv1Id;

    @ApiModelProperty(value="榜单类型:hot热租 pricedown降价 newon新品")
    private String  rankType;


}
