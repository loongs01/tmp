package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author zhoutw
 * @date 2023年12月18日 17:17
 */
@Data
public class MerchantRateRespDto   implements Serializable {


    @ApiModelProperty(value="merchantCode")
    private String  merchantCode;

    @ApiModelProperty(value="fst_hand_delivery_rate")
    private double  fstHandDeliveryRate =0.0D;

    public MerchantRateRespDto() {
    }

    public MerchantRateRespDto(final String merchantCode, final double fstHandDeliveryRate) {
        this.merchantCode = merchantCode;
        this.fstHandDeliveryRate = fstHandDeliveryRate;
    }
}
