package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.math.BigInteger;

/**
 * @Auther:qiukai
 * @Date:2024/4/1 15:16
 */

@Data
public class GoodsFirstPageListCateResDto {

    @ApiModelProperty(value="1、精选商品、2分类商品")
    private String  catePageType;

    @NotEmpty(message = "channelNo 不能为空")
    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    @ApiModelProperty(value="一级分类页id 不能为空")
    private BigInteger catePageLv1Id;

    @ApiModelProperty(value="一级分类页名称 不能为空")
    private String catePageLv1Name;

    @ApiModelProperty(value="订单来源")
    private String sourceOrder;




}
