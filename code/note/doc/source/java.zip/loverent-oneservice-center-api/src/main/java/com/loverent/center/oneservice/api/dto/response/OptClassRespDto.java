package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class OptClassRespDto implements Serializable {


    @ApiModelProperty(value="类目ID")
    private String  optClassCode ;

    @ApiModelProperty(value="类目名称")
    private String  optClassName  ;

}
