package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * top50请求参数
 * @author stogel
 */
@Data
public class BigDataRankGoodsTop50RespDto {

    @ApiModelProperty(value="一级分类页ID")
    private Long  catePageLv1Id;

    @ApiModelProperty(value="榜单类型:hot热租 pricedown降价 newon新品")
    private String  rankType;

    @ApiModelProperty(value="商品编码")
    private String  goodsCode;

    @ApiModelProperty(value="排序因子:热租:近7日申请订单数 降价:日租金降价幅度 新品:GMV新增幅度")
    private BigDecimal rankBase;

    @ApiModelProperty(value="spu编码")
    private String  spuCode;
}
