package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessMainReqDto  implements Serializable {

    @NotEmpty(message = "指标统计开始日期 不能为空")
    @ApiModelProperty(value="指标统计开始日期")
    private Date statStartDate;

    @NotEmpty(message = "指标统计结束日期 不能为空")
    @ApiModelProperty(value="指标统计结束日期")
    private Date statEndDate;

    @NotEmpty(message = "merchantCode 不能为空")
    @ApiModelProperty(value="merchantCode")
    private String  merchantCode;
}
