package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class OptClassListReqDto implements Serializable {

    @ApiModelProperty(value="指标统计开始日期")
    private Date statStartDate;

    @ApiModelProperty(value="指标统计结束日期")
    private Date statEndDate;

    @ApiModelProperty(value="merchantCode")
    private String  merchantCode;


    @NotEmpty(message = "列表类型,默认-1:  1-平台，2-商户")
    @ApiModelProperty(value="classType")
    private Integer  classType=1;

}
