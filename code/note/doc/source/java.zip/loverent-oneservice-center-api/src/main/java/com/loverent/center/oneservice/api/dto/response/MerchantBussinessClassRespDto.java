package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessClassRespDto  implements Serializable {


    @ApiModelProperty(value="类目ID")
    private String  optClassCode ;


    @ApiModelProperty(value="类目名称")
    private String  optClassName  ;

    @ApiModelProperty(value="租赁方案分布-租完即送成交订单占比")
    private double  rentfreePayOrdRate = 0.00;

    @ApiModelProperty(value="租赁方案分布-租完归还成交订单占比")
    private double  rentreturnPayOrdRate  = 0.00;

}
