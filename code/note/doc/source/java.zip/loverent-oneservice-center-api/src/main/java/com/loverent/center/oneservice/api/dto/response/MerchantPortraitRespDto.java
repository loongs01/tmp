package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.io.Serializable;
import java.math.BigDecimal;

/**
 * @author zhengjianhua
 * @version 1.0
 * @date 2023/4/11 10:08
 */
@ApiModel(value = "MerchantPortraitResp 对象")
@Data
public class MerchantPortraitRespDto implements Serializable {

    @ApiModelProperty("商户编码")
    private String merchantCode;

    /**
     * 加权平均发货率
     * ，240626新增
     */
    @ApiModelProperty("加权平均发货率")
    private BigDecimal merchantWeightAvg;

    @ApiModelProperty("统计时间")
    private String censusTime;
    /**
     * 首单通过率(该商户一手单审批通过订单数/一手单申请数)
     */
    @ApiModelProperty("首单通过率(该商户一手单审批通过订单数/一手单申请数)")
    private BigDecimal firstOrderPassRate;
    /**
     * 今日接单量
     */
    @ApiModelProperty("今日接单量")
    private Long todayRecOrder;
    /**
     * 累计申请资产包(申请该商户的所有订单的签约价合计金额)
     */
    @ApiModelProperty("累计申请资产包(申请该商户的所有订单的签约价合计金额)")
    private BigDecimal applyAssetTotal;
    /**
     * 统计14天内 出库的商品的台数
     */
    @ApiModelProperty("统计14天内 出库的商品的台数")
    private Long fourteenOutBound;
    /**
     * 一手发货率
     */
    @ApiModelProperty("一手发货率")
    private BigDecimal firstOutBound;
    /**
     * 二手发货率
     */
    @ApiModelProperty("二手发货率")
    private BigDecimal secondOutBound;
    /**
     * 平均审批时效（小时）
     */
    @ApiModelProperty("平均审批时效")
    private BigDecimal avgAuditTime;
    /**
     * 平均发货时效（小时）
     */
    @ApiModelProperty("平均发货时效")
    private BigDecimal avgShipTime;
    /**
     * 逾期率
     */
    @ApiModelProperty("逾期率")
    private BigDecimal overdueRate;
    /**
     * 客诉率
     */
    @ApiModelProperty("客诉率")
    private BigDecimal customerComplaintRate;
    /**
     * 手机品类发货率
     */
    @ApiModelProperty("手机品类发货率")
    private BigDecimal phoneShipmentRate;
    /**
     * 手机品类订单占比
     */
    @ApiModelProperty("手机品类订单占比")
    private BigDecimal phoneShipmentRatio;
    /**
     * 电脑品类发货率
     */
    @ApiModelProperty("电脑品类发货率")
    private BigDecimal computerShipmentRate;
    /**
     * 电脑品类订单占比
     */
    @ApiModelProperty("电脑品类订单占比")
    private BigDecimal computerShipmentRatio;
    /**
     * 其他品类发货率
     */
    @ApiModelProperty("其他品类发货率")
    private BigDecimal otherShipmentRate;
    /**
     * 其他品类订单占比
     */
    @ApiModelProperty("其他品类订单占比")
    private BigDecimal otherShipmentRatio;
    /**
     * 统计周期内一手订单出库商品的总签约价
     */
    @ApiModelProperty("统计周期内一手订单出库商品的总签约价")
    private BigDecimal outAvgSignAmount;

    /**
     * 非工作时间平均发货时效(小时)
     */
    @ApiModelProperty("非工作时间平均发货时效")
    private BigDecimal avgFreeShipTime;
    /**
     * 工作时间平均发货时效(小时)
     */
    @ApiModelProperty("工作时间平均发货时效")
    private BigDecimal avgWorkShipTime;

    /**
     * 非工作时间平均审批时效(小时)
     */
    @ApiModelProperty("非工作时间平均审批时效")
    private BigDecimal avgFreeAuditTime;
    /**
     * 工作时间平均发货时效(小时)
     */
    @ApiModelProperty("工作时间平均审批时效")
    private BigDecimal avgWorkAuditTime;

    /**
     * 统计14天内 支付宝端内申请数量
     */
    @ApiModelProperty("统计14天内 支付宝端内申请数量")
    private Long fourteenApplyBound;

    /**
     * 统计14天内 芝麻渠道申请数量
     */
    @ApiModelProperty("统计14天内芝麻渠道申请数量")
    private Long fourteenZmApplyBound;

    /**
     * 统计14天内 微信申请数量
     */
    @ApiModelProperty("统计14天内 微信申请数量")
    private Long fourteenApplyWxBound =0L;
    /**
     * 统计14天内 其他申请数量
     */
    @ApiModelProperty("统计14天内 其他申请数量")
    private Long fourteenApplyOtherBound=0L;

    /**
     * 统计14天内 抖音申请数量
     */
    @ApiModelProperty("统计14天内 抖音申请数量")
    private Long fourteenApplyDyBound=0L;

    /**
     * 统计周期内一手订单电脑品类出库商品的总签约价
     */
    @ApiModelProperty("统计周期内一手订单电脑品类出库商品的平均签约价")
    private BigDecimal computerAvgOutSignAmount;

    /**
     * 统计周期内一手订单其他品类出库商品的总签约价
     */
    @ApiModelProperty("统计周期内一手订单其他品类出库商品的平均约价")
    private BigDecimal otherAvgOutSignAmount;

    /**
     * 高客单价接单率（实时）
     */
    @ApiModelProperty("高客单价接单率（实时）")
    private BigDecimal highGteOrderRate;

    /**
     * 高客单价接单率（7天）
     */
    @ApiModelProperty("高客单价接单率（实时）")
    private BigDecimal sevenDayHighGteOrderRate;

    /**
     * 今日接单量
     */
    @ApiModelProperty("今日接单量")
    private Long todaySecRecOrder;

    /**
     * 加权平均发货率
     */
    @ApiModelProperty("加权平均发货率")
    private BigDecimal weightedAvg;


    /**
     * 今日总接单量
     */
    @ApiModelProperty("今日总接单量")
    private Long todayTotalRecOrder;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
