package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;

/**
 * @Auther:qiukai
 * @Date:2024/5/13 10:24
 */

@Data
public class MerchantGoodsNumRankResDto {

    @ApiModelProperty(value="商户编码")
    private String merchantCode;

    @ApiModelProperty(value="商户名称")
    private String merchantName;

    @ApiModelProperty(value="商户合作类型：1-自营，2-商户，3-线下合伙人")
    private BigInteger merchantType;

    @ApiModelProperty(value="商品图片")
    private String spuImg;

    @ApiModelProperty(value="商品编码")
    private String goodsCode;

    @ApiModelProperty(value="商品标题")
    private String goodsTitle;

    @ApiModelProperty(value="商品销量排名")
    private BigInteger orderNumRank;

}
