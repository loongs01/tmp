package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessMainRateRespDto implements Serializable {


    @ApiModelProperty(value="出库订单分布-自发已出库订单占比")
    private double  selfshipOutboundOrdRate =0.00;

    @ApiModelProperty(value="出库订单分布-代发已出库订单占比")
    private double  agentshipOutboundOrdRate=0.00;

    @ApiModelProperty(value="是否包含手机品类")
    private boolean  isHasPhoneClass;

}
