package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;
import java.util.List;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessMainRespDto  implements Serializable {

    @ApiModelProperty(value="指标统计开始日期")
    private Date statStartDate;

    @ApiModelProperty(value="指标统计结束日期")
    private Date statEndDate;

    @ApiModelProperty(value="merchantCode")
    private String  merchantCode;

    @ApiModelProperty(value="品类维度")
    List<MerchantBussinessMainClassRespDto> mainClassRespDtos;


    @ApiModelProperty(value="用户风险维度")
    List<MerchantBussinessMainRiskRespDto> mainRiskRespDtos;


    @ApiModelProperty(value="订单比率")
    MerchantBussinessMainRateRespDto mainRateRespDtos;


    @ApiModelProperty(value="热门机型列表")
    private List<MerchantBussinessMainModelRespDto>  mainModelRespDtos;

}
