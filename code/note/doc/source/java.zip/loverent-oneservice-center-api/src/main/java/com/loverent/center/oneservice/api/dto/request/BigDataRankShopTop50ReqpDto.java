package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/5/17 17:54
 */


@Data
public class BigDataRankShopTop50ReqpDto {

    private List<String> cateLv1Codes;

}
