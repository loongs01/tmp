package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/5/15 14:20
 */

@Data
public class GoodsOrderListReqDto {

    @ApiModelProperty(value="渠道编码")
    private String channelNo;

    @ApiModelProperty(value="商品code集合")
    private List<String> goodsCode;

}
