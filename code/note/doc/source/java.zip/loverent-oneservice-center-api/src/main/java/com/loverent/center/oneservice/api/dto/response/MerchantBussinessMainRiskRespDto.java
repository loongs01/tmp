package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessMainRiskRespDto implements Serializable {



    @ApiModelProperty(value="用户风险编码")
    private String  userRiskCode;

    @ApiModelProperty(value="平台预收多期-用户风险实收期数")
    private BigDecimal  prePaymentPeriods;

    @ApiModelProperty(value="平台预收多期-用户风险维度发货率")
    private double  riskFstHandDeliveryRate;

    @ApiModelProperty(value="用户风险维度-平均签约价")
    private double  riskAvgSignAmt;

    @ApiModelProperty(value="申请用户分布")
    private double  riskApplyOrdRate;

    @ApiModelProperty(value="机型编号")
    private Long  materielModelId;

    @ApiModelProperty(value="热门机型-机型名称")
    private String  materielModelName;

    @ApiModelProperty(value="热门机型-出库订单数")
    private Long  outboundOrdNum;

    @ApiModelProperty(value="热门机型-出库订单排名")
    private Long  outboundOrdRank;
}
