package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @Auther:qiukai
 * @Date:2024/4/1 18:26
 */

@Data
public class MerchantListReqDto {

    @NotEmpty(message = "一级类目编码 不能为空")
    @ApiModelProperty(value = "一级类目编码")
    private String cateLv1Code;

    @ApiModelProperty(value = "店铺编码")
    private String merchantCode;

    @ApiModelProperty(value="当前页面")
    private Integer currPage;

    @ApiModelProperty(value="页面条数")
    private Integer pageSize;

}
