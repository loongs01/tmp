package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @Auther:qiukai
 * @Date:2024/5/13 12:41
 */

@Data
public class MerchantCateListReqDto {
    @ApiModelProperty(value="当前页面")
    private Integer currPage;

    @ApiModelProperty(value="页面条数")
    private Integer pageSize;
}
