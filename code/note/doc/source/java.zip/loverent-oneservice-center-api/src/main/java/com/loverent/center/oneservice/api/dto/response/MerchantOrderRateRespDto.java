package com.loverent.center.oneservice.api.dto.response;

import com.fasterxml.jackson.annotation.JsonFormat;
import com.loverent.common.dto.BaseDto;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;


@ApiModel(value = "MerchantOrderRateRespDto", description = "商户订单统计")
@Data
public class MerchantOrderRateRespDto implements Serializable {

    @ApiModelProperty(value="merchantCode")
    private String merchantCode;

    @ApiModelProperty(value="总平均续租率")
    private double avgReletOrdRateTd;

    @ApiModelProperty(value="续租率")
    private double reletOrdRateTd;

    @ApiModelProperty(value="买断率")
    private double buyoutOrdRateTd;

    @ApiModelProperty(value="平均买断率")
    private double avgBuyoutOrdRateTd;

    @ApiModelProperty(value=" 归还率")
    private double returnOrdRateTd;

    @ApiModelProperty(value="平均归还率")
    private double avgReturnOrdRateTd;

    @ApiModelProperty(value="提前归还率")
    private double earlyReturnOrdRateTd;

    @ApiModelProperty(value="'累计已出库订单数'")
    private long outboundOrdNumTd;

    @ApiModelProperty(value="'本月已出库订单数'")
    private long outboundOrdNumMtd;

    @ApiModelProperty(value="'昨日已出库订单数'")
    private long outboundOrdNum1d;

    @ApiModelProperty(value=" '累计已成交订单数'")
    private long payOrdNumTd;

    @ApiModelProperty(value="'本月已成交订单数'")
    private long payOrdNumMtd;

    @ApiModelProperty(value="'昨日已成交订单数'")
    private long payOrdNumLd;

    @JsonFormat(pattern = "yyyy-MM-dd HH:mm:ss", timezone = "GMT+8")
    @ApiModelProperty(value = "创建时间", name = "createTime")
    private Date statDate;

    @ApiModelProperty(value="近7日苹果手机接单率(百分比)")
    private double iphoneRevOrdRate7d;

    @ApiModelProperty(value="今日苹果手机接单率(百分比)")
    private double iphoneRevOrdRateth;

    @ApiModelProperty(value="今日全新手机接单率")
    private double newMobileRevOrdRateTh ;

    @ApiModelProperty(value="近7日全新手机接单率")
    private double newMobileRevOrdRate7d;

}
