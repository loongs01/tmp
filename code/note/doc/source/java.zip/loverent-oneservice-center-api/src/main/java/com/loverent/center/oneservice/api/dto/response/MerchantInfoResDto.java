package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;
import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/5/14 22:39
 */

@Data
public class MerchantInfoResDto {
    @ApiModelProperty(value="商户编码")
    private String merchantCode;

    @ApiModelProperty(value="商户名称")
    private String merchantName;

    @ApiModelProperty(value="商户合作类型：1-自营，2-商户，3-线下合伙人")
    private BigInteger merchantType;

    @ApiModelProperty(value="店铺头像")
    private String shopAvatarImg;

    @ApiModelProperty(value="店铺名称")
    private String shopName;


    @ApiModelProperty(value="店铺星级评分（1）商户：取商户系统-数据看板2）自营：默认显示最高分100分）")
    private BigDecimal shopScore;

    @ApiModelProperty(value="店铺星级评分排序")
    private BigInteger shopScoreRk;

    @ApiModelProperty(value="提交到（状态：1 待审批）的订单总量")
    private BigInteger orderTotalNum;

    @ApiModelProperty(value="上架商品")
    private BigInteger onShelfGoodsNum;

    @ApiModelProperty(value="累计出库")
    private BigInteger outBoundNum;

    @ApiModelProperty(value="平均发货率")
    private BigDecimal avgDeliveryRate;

    @ApiModelProperty(value="客诉率")
    private BigDecimal customerComplaintrate;

    @ApiModelProperty(value="平均审核时效")
    private BigDecimal avgAuditTime;

    @ApiModelProperty(value="平均发货时效")
    private BigDecimal avgShipTime;


}
