package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessModelRespDto  implements Serializable {

    @ApiModelProperty(value="平台热门机型-机型编号")
    private Long  materielModelId;

    @ApiModelProperty(value="平台热门机型-机型名称")
    private String  materielModelName;

    @ApiModelProperty(value="平台热门机型-申请订单数")
    private long  applyOrdNum;

    @ApiModelProperty(value="平台热门机型-申请订单排名")
    private long  applyOrdRank;

}
