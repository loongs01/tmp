package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessMainModelRespDto implements Serializable {


    @ApiModelProperty(value="机型编号")
    private Long  materielModelId;

    @ApiModelProperty(value="热门机型-机型名称")
    private String  materielModelName;

    @ApiModelProperty(value="热门机型-出库订单数")
    private Long  outboundOrdNum;

    @ApiModelProperty(value="热门机型-出库订单排名")
    private Long  outboundOrdRank;


}
