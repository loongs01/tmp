package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.math.BigInteger;

/**
 * @Auther:qiukai
 * @Date:2024/5/11 17:34
 */

@Data
public class GoodsFirstPageSelectedListReqDto {
    @ApiModelProperty(value="商品标题")
    private String  goodsTitle;

    @ApiModelProperty(value="spu编码")
    private String  spuCode;

    @ApiModelProperty(value="商品编码")
    private String  goodsCode ;

    @NotEmpty(message = "channelNo 不能为空")
    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    @ApiModelProperty(value="当前页面")
    private Integer currPage;

    @ApiModelProperty(value="页面条数")
    private Integer pageSize;
}
