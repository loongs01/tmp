package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;

/**
 * top50请求参数
 * @author stogel
 */
@Data
public class BigDataRankShopTop50RespDto {

    @ApiModelProperty(value="一级类目编码")
    private String cateLv1Code;

    @ApiModelProperty(value="商户合作类型：1-自营，2-商户，3-线下合伙人")
    private Integer merchantType;

    @ApiModelProperty(value="商户编码")
    private String merchantCode;

    @ApiModelProperty(value="星级榜:自营：默认显示最高分100分）")
    private BigDecimal rankBase;
}
