package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/4/2 10:50
 */

@Data
public class MerchantListCateResDto {
    @NotEmpty(message = "一级类目编码 不能为空")
    @ApiModelProperty(value="一级类目编码")
    private  String cateLv1Code;

    @ApiModelProperty(value="一级类目名称")
    private  String cateLv1Name;

    @ApiModelProperty(value="经营店铺数")
    private  String merchantNums;

}
