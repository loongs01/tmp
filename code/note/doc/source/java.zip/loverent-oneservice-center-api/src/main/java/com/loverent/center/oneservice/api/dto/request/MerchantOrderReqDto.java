package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantOrderReqDto implements Serializable {

    @NotEmpty(message = "merchantCode 不能为空")
    @ApiModelProperty(value="merchantCode")
    private String  merchantCode;
}
