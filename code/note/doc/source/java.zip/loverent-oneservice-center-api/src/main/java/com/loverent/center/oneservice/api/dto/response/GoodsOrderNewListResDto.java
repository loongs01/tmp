package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @Auther:qiukai
 * @Date:2024/5/15 14:21
 */

@Data
public class GoodsOrderNewListResDto {
    @ApiModelProperty(value="商品ID")
    private BigInteger goodsId ;

    @ApiModelProperty(value="商品编码")
    private String  goodsCode  ;

    @ApiModelProperty(value="商品标题")
    private String  goodsTitle;

    @ApiModelProperty(value="spu编码")
    private String  spuCode;

    @ApiModelProperty(value="商品首次上架月份")
    private String  onShelfMonth;

    @ApiModelProperty(value="商品型号")
    private String  modelName;

    @ApiModelProperty(value="成新度")
    private String  materielNewoldConfigName;

    @ApiModelProperty(value="spu图片")
    private String  goodsSpuImg;

    @ApiModelProperty(value="商户编码")
    private String  merchantCode;

    @ApiModelProperty(value="商户名称")
    private String  merchantName;

    @ApiModelProperty(value="商户合作类型：1-自营，2-商户，3-线下合伙人")
    private BigInteger  merchantType;

    @ApiModelProperty(value="租赁类型code")
    private String  leaseMoldCode;

    @ApiModelProperty(value="租赁类型名称")
    private String  leaseMoldName;

    @ApiModelProperty(value="渠道编码")
    private String  channelNo;

    @ApiModelProperty(value="申请订单数")
    private BigInteger  applyOrderNumTd;

    @ApiModelProperty(value="近30日出库订单数")
    private BigInteger  outboundOrder30d;

    @ApiModelProperty(value="1、连续霸榜1周 2、连续霸榜2周 3、连续霸榜3周 4、连续霸榜1个月")
    private BigInteger  continuouslyFlag;

    @ApiModelProperty(value="GMV新增幅度")
    private BigDecimal  gmvIncrease;

    @ApiModelProperty(value="GMV新增幅度排名")
    private BigInteger gmvIncreaseRk;

    @ApiModelProperty(value="排名变动")
    private BigInteger  changeRk;

    @ApiModelProperty(value="相同一级分类下商品重复数据靠重新排序")
    private BigInteger  sampleGoodsGmvIncreaseRk;

    @ApiModelProperty(value="相同商品不同分类商品重复数据重新排序")
    private BigInteger  sampleGoodsNumRk;

    @ApiModelProperty(value="sku数量")
    private BigInteger  skuNum;


}
