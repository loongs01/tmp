package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessMainClassRespDto implements Serializable {


    @ApiModelProperty(value="运营品类编码")
    private String  optClassCode;

    @ApiModelProperty(value="运营品类名称")
    private String  optClassName;

    @ApiModelProperty(value="品类维度发货率")
    private double  fstHandDeliveryRate;

    @ApiModelProperty(value="品类维度平均签约价")
    private double  avgSignAmt;

}
