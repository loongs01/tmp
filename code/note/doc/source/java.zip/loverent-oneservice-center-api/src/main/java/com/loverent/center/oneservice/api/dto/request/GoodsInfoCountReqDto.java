package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.api.dto.request
 * @ClassName GoodsInfoReqDto
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  14:06
 */
@Data
public class GoodsInfoCountReqDto {
    @ApiModelProperty(value = "类目编码")
    //private String cateCode;
    private List<String> typeCodeList;


    @ApiModelProperty(value = "品牌编码")
    //private String brandCode;
    private List<String> brandCodeList;


    @ApiModelProperty(value = "型号编码")
    //private String modelCode;
    private List<String> modelCodeList;


    @ApiModelProperty(value = "商户类型1 自营 2商户 3合伙人")
    //private String merchantType;
    private List<Integer> merchantTypeList;

    @ApiModelProperty(value = "商户编	码列表 具体商户编码")
    private List<String> merchantCodeList;

    @ApiModelProperty(value = "租赁类型编码，activityRent1/activitySale1/standardRent/standardSale")
    //private List<Integer> leaseMoldType;
    private List<String> leaseMoldCodeList;

    @ApiModelProperty(value = "物料新旧程度配置id全新：1,99新：2,95新：3,90新：4,准新机：5,80新：6,70新：7 ")
    //private String materielNewoldConfigId;
    private List<Integer> newConfigIdList;

    @ApiModelProperty(value = "租期类型列表  (1长租 2短租)")
    private List<Integer> leaseTermTypeList;


    //@ApiModelProperty(value="优惠券类型：首期款租金券、租金还款券、买断券、延长还机时间券、总租金券")
    //private String coupon_type;
    @ApiModelProperty(value = "优惠卷类型列表 (优惠券类型 1首期款租金券，2租金还款券，3买断券，4售卖券，5延长还机时间劵，6总租金券)")
    private List<Integer> discountTypeList;


    public List<Integer> getNewConfigIdList() {
        if (CollectionUtils.isEmpty(newConfigIdList)) {
            return newConfigIdList;
        }
        return newConfigIdList.stream().filter(type -> type > 0 && type < 8).collect(Collectors.toList());
    }

    public List<Integer> getLeaseTermTypeList() {
        if (CollectionUtils.isEmpty(leaseTermTypeList)) {
            return leaseTermTypeList;
        }
        return leaseTermTypeList.stream().filter(type -> type > 0 && type < 3).collect(Collectors.toList());
    }

    public List<Integer> getDiscountTypeList() {
        if (CollectionUtils.isEmpty(discountTypeList)) {
            return discountTypeList;
        }
        return discountTypeList.stream().filter(type -> type > 0 && type < 7 && type != 4).collect(Collectors.toList());
    }

}
