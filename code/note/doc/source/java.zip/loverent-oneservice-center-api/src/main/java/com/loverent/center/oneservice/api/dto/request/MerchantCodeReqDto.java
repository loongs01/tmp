package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;

/**
 * @Auther:qiukai
 * @Date:2024/4/2 11:10
 */

@Data
public class MerchantCodeReqDto {

    @NotEmpty(message = "商户编码 不能为空")
    @ApiModelProperty(value="商户编码")
    private String merchantCode;


}
