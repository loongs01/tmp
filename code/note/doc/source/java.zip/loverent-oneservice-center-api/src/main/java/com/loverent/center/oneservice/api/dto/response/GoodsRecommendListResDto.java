package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigInteger;
import java.util.List;

/**
 * 更多商品分类
 * @author stogel
 */
@Data
public class GoodsRecommendListResDto {

    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    @ApiModelProperty(value="一级分类页id 不能为空")
    private BigInteger catePageLv1Id;

    @ApiModelProperty(value="一级分类页名称 不能为空")
    private String catePageLv1Name;

    @ApiModelProperty(value="申请订单数")
    private BigInteger  applyOrderNumTd;

    @ApiModelProperty(value="一级分类页名称 不能为空")
    private String outboundOrder7d;

    @ApiModelProperty(value="榜单类型:hot热租 pricedown降价 newon新品")
    private String  rankType;

    @ApiModelProperty(value="内部来源标识")
    private String orderSource;


    List<GoodsRecommendListGoodsReqDto> goodsInfo;
}
