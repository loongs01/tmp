package com.loverent.center.oneservice.api.dto.request;

import com.alibaba.fastjson.annotation.JSONField;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.format.annotation.DateTimeFormat;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月07日 17:30
 */
@Data
public class MerchantBussinessModelReqDto  implements Serializable {

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @ApiModelProperty(value="指标统计开始日期")
    private Date statStartDate;

    @JSONField(format = "yyyy-MM-dd HH:mm:ss")
    @NotEmpty(message = "指标统计结束日期 不能为空")
    @ApiModelProperty(value="指标统计结束日期")
    private Date statEndDate;


    @ApiModelProperty(value="类目ID")
    private String  optClassCode ;


    @ApiModelProperty(value="类目名称")
    private String  optClassName  ;
}
