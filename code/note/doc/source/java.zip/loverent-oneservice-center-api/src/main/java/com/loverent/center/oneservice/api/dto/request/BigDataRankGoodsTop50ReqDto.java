package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.util.List;

/**
 * top50请求参数
 * @author stogel
 */
@Data
public class BigDataRankGoodsTop50ReqDto {

    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    private List<BigDataRankGoodsTop50BodyReqDto> catePageLv1IdRankTypes;

}
