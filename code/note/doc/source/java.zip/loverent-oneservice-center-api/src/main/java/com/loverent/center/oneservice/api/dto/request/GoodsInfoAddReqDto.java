package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.springframework.util.CollectionUtils;

import javax.validation.Valid;
import javax.validation.constraints.*;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.api.dto.request
 * @ClassName GoodsInfoAddReqDto
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  14:06
 */
@Data
public class GoodsInfoAddReqDto {
    @ApiModelProperty(value = "商品编码")
    //private String cateCode;
    private List<String> goodsCodeList;



    @ApiModelProperty(value = "排序规则列表")
    @NotEmpty(message = "排序规则列表不可为空")
    @Size(min = 3, max = 3, message = "排序规则列表限制3个")
    @Valid
    private List<SortingRule> sortingRuleList;

     /*   public  List<Integer> discountTypeListTransform(){
            List<Integer> list = new ArrayList<>();
            HashSet<Integer> discountTypeSet = new HashSet<>(discountTypeList);

            for (int i = 1; i <= 6; i++) {
                int e = discountTypeList.contains(i) ? 1 : 0;
                list.add(e);
            }
            return list;
        }*/


    @ApiModel(value = "新增活动自动选品排序规则")
    @Data
    public static class SortingRule {

        @ApiModelProperty(value = "排序规则类型 1申请量 2出库量 3发货率")
        @NotNull(message = "排序规则类型不可为空")
        @Min(value = 1, message = "排序规则类型限制1申请量 2出库量 3发货率")
        @Max(value = 3, message = "排序规则类型限制1申请量 2出库量 3发货率")
        private Integer ruleType;

        @ApiModelProperty(value = "周期 天数")
        @NotNull(message = "周期 天数不可为空")
        private Integer cycleDays;

        @ApiModelProperty(value = "权重 百分比")
        @NotNull(message = "权重不可为空")
        @Min(value = 1, message = "权重限制1-100")
        @Max(value = 100, message = "权重限制1-100")
        private Integer weight;
    }

}
