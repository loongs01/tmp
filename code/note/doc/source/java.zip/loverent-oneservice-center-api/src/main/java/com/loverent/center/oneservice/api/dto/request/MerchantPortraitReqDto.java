package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import org.apache.commons.lang3.builder.ToStringBuilder;

import java.util.List;

@ApiModel(value="MerchantPortraitReqDtov1 对象")
@Data
public class MerchantPortraitReqDto {

    /**
     * 商户编码
     */
    @ApiModelProperty(value="商户编码")
    private List<String> merChantCode;

    @Override
    public String toString() {
        return ToStringBuilder.reflectionToString(this);
    }
}
