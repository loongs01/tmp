package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/5/14 19:03
 */

@Data
public class MerchantListTop3ResDto {
    @NotEmpty(message = "一级类目编码 不能为空")
    @ApiModelProperty(value="一级类目编码")
    private  String cateLv1Code;

    @ApiModelProperty(value="一级类目名称")
    private  String cateLv1Name;

    @ApiModelProperty(value="提交到（状态：1 待审批）的订单总量")
    private  String orderTotalNum;

    @ApiModelProperty(value="提交到（状态：1 待审批）的订单总量")
    private List<MerchantListResDto> merchantListResDto;

}
