package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;

@Data
public class GoodsFirstPageListCateReqDto implements Serializable {


    @NotEmpty(message = "channelNo 不能为空")
    @ApiModelProperty(value="channelNo")
    private String  channelNo;

}
