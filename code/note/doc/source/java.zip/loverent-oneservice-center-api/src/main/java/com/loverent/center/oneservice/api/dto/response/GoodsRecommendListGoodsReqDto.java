package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.math.BigDecimal;
import java.math.BigInteger;


@Data
public class GoodsRecommendListGoodsReqDto {

    @ApiModelProperty(value="一级分类页id 不能为空")
    private BigInteger catePageLv1Id;

    @ApiModelProperty(value="一级分类页名称 不能为空")
    private String catePageLv1Name;

    @ApiModelProperty(value="商品编码")
    private String  goodsCode  ;

    @ApiModelProperty(value="spu编码")
    private String  spuCode;

    @ApiModelProperty(value="商品标题")
    private String  goodsTitle;

    @ApiModelProperty(value="租赁类型code")
    private String  leaseMoldCode;

    @ApiModelProperty(value="商品型号")
    private String  modelName;

    @ApiModelProperty(value="spu图片")
    private String  goodsSpuImg;

    @ApiModelProperty(value="相同商品重新排名")
    private String  sampleGoodsModelNumRk;

    @ApiModelProperty(value="排名变动")
    private Long  changeRk;

    /** 热租相关 */
    @ApiModelProperty(value="申请订单数")
    private BigInteger  applyOrderNumTd;

    @ApiModelProperty(value="近7日申请订单数")
    private BigInteger applyOrderNum7d;

    /** 新品相关 */
    @ApiModelProperty(value="商品首次上架月份")
    private String  onShelfMonth;

    @ApiModelProperty(value="GMV新增幅度")
    private BigDecimal  gmvIncrease;

    /** 降价相关 */
    @ApiModelProperty(value="原总租金")
    private BigDecimal  totalAmount;

    @ApiModelProperty(value="优惠总金额")
    private BigDecimal  couponTotalAmount;

    @ApiModelProperty(value="降价幅度")
    private BigDecimal priceReductionPercentage;

}
