package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.api.dto.response
 * @ClassName GoodsInfoCountResDto
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  21:42
 */
@Data
public class GoodsInfoCountResDto {
    @ApiModelProperty(value = "商品池数量")
    private String goodsNums;
}
