package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.io.Serializable;
import java.math.BigInteger;



@Data
public class GoodsFirstPageListReqDto implements Serializable {

    @ApiModelProperty(value="商品标题")
    private String  goodsTitle;

    @ApiModelProperty(value="spu编码")
    private String  spuCode;

    @ApiModelProperty(value="商品编码")
    private String  goodsCode ;

    @NotEmpty(message = "channelNo 不能为空")
    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    @ApiModelProperty(value="一级分类页id 不能为空")
    private BigInteger catePageLv1Id;

    @ApiModelProperty(value="当前页面")
    private Integer currPage;

    @ApiModelProperty(value="页面条数")
    private Integer pageSize;

}
