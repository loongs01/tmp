package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;
import springfox.documentation.service.ApiListing;

import javax.validation.constraints.NotNull;
import java.util.List;

/**
 * 更多商品分类
 * @author stogel
 */
@Data
public class GoodsRecommendListReqDto {
    @NotNull
    @ApiModelProperty(value="channelNo")
    private String  channelNo;

    @ApiModelProperty(value="一级分类页id")
    private List<GoodsRecommendListPageReqDto> goodsRecommendListPageReqDto;
}
