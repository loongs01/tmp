package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotNull;

/**
 * @Auther:qiukai
 * @Date:2024/5/14 20:41
 */

@Data
public class GoodsRecommendListPageReqDto {

    @NotNull
    @ApiModelProperty(value="榜单类型:hot热租 pricedown降价 newon新品")
    private String  rankType;

    @NotNull
    @ApiModelProperty(value="分类页id")
    private String  catePageLv1Id;



}
