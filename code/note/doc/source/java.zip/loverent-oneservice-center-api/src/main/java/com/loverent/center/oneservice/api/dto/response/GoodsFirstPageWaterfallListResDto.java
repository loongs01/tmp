package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.NotNull;
import java.math.BigDecimal;
import java.math.BigInteger;

/**
 * @Auther:qiukai
 * @Date:2024/4/1 16:00
 */

@Data
public class GoodsFirstPageWaterfallListResDto {

    @ApiModelProperty(value="商品ID")
    private BigInteger goodsId ;

    @ApiModelProperty(value="商品编码")
    private String goodsCode ;

    @ApiModelProperty(value="一级分类页ID")
    private String  catePageLv1Id;

    @ApiModelProperty(value="一级分类页名称")
    private String  catePageLv1Name;

    @ApiModelProperty(value="商户编码")
    private String  merchantCode;

    @ApiModelProperty(value="商户名称")
    private String  merchantName;

    @ApiModelProperty(value="商户合作类型：1-自营，2-商户，3-线下合伙人")
    private BigInteger  merchantType;

    @ApiModelProperty(value="渠道")
    private String  channelNo;

    @ApiModelProperty(value="榜单类型:hot热租 pricedown降价 newon新品")
    private String  rankType;

    @ApiModelProperty(value="排序因子:热租:近7日申请订单数 降价:日租金降价幅度 新品:GMV新增幅度")
    private BigDecimal rankBase;

    @ApiModelProperty(value="排名值")
    private Integer  listRk;






}
