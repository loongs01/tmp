package com.loverent.center.oneservice.api.dto.request;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import javax.validation.constraints.NotEmpty;
import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/5/14 22:40
 */

@Data
public class MerchantInfoReqDto {

    @NotEmpty(message = "商户编码 不能为空")
    @ApiModelProperty(value="商户编码")
    private List<String>merchantInfo;

}
