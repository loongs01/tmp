package com.loverent.center.oneservice.api.dto.response;

import io.swagger.annotations.ApiModelProperty;
import lombok.Data;

import java.io.Serializable;
import java.math.BigDecimal;
import java.math.BigInteger;
import java.math.RoundingMode;
import java.util.Objects;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.api.dto.response
 * @ClassName GoodsInfoResDto
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  13:49
 */
@Data
public class GoodsInfoResDto implements Serializable {

    @ApiModelProperty(value = "商品标题")
    private String productTitle;

    @ApiModelProperty(value = "spu图片")
    private String spuImg;

    @ApiModelProperty(value = "spu编码")
    private String spuCode;

    @ApiModelProperty(value = "商品编码")
    private String goodsCode;

    @ApiModelProperty(value = "类目编码")
    private String typeCode;

    @ApiModelProperty(value = "品牌编码")
    private String brandCode;

    @ApiModelProperty(value = "型号编码")
    private String modelCode;

    @ApiModelProperty(value = "类目名称")
    private String typeName;

    @ApiModelProperty(value = "商户编号")
    private String merchantCode;

    @ApiModelProperty(value = "商户名称")
    private String merchantName;

    @ApiModelProperty(value = "商户类型 1自营 2商户")
    private Integer merchantType;

    @ApiModelProperty(value = "申请量")
    private Integer applyCount;
    /**
     * 出库量
     */
    @ApiModelProperty(value = "出库量")
    private Integer outboundCount;
    /**
     * 发货率
     */
    @ApiModelProperty(value = "发货率")
    private BigDecimal deliveryRate;
    /**
     * 权重
     */
    @ApiModelProperty(value = "权重(分数)")
    private BigDecimal weight;


    public BigDecimal getWeight() {
        if (Objects.isNull(weight)) {
            return null;
        }
        return weight.setScale(2, RoundingMode.HALF_DOWN);
    }

    public BigDecimal getDeliveryRate() {
        if (Objects.isNull(deliveryRate)) {
            return null;
        }
        return deliveryRate.setScale(2,RoundingMode.HALF_DOWN);
    }


}
