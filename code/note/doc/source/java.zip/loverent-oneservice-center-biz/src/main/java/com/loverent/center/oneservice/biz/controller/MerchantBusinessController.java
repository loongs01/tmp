package com.loverent.center.oneservice.biz.controller;

import com.baomidou.mybatisplus.extension.exceptions.ApiException;
import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import com.loverent.center.oneservice.biz.service.MerchantBusinessService;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.apache.commons.lang3.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * @author zhoutw
 * @date 2023年12月07日 14:18
 */
@Slf4j
@Api("商户标签控制器")
@ApiModel(description = "商户标签控制器")
@RestController
@RequestMapping("/data/merchant")
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class MerchantBusinessController {


    @Autowired
    MerchantBusinessService service;


    @PostMapping("/query/optClass")
    @ApiOperation("获取有效类目列表")
    public RestResponse<List<OptClassRespDto>> getOrderRate(@RequestBody OptClassListReqDto reqDto) {

        Integer type = reqDto.getClassType();
        List<OptClassRespDto> aClass = new ArrayList<>();
        if (type == 2 && StringUtils.isNotBlank(reqDto.getMerchantCode()) && reqDto.getStatStartDate() != null) {
            aClass = service.getOptClass(reqDto);
        } else {
            aClass = service.getOptClass();
        }
        RestResponse<List<OptClassRespDto>> response = RestResponse.buildSuccessResponse(aClass);
        return response;
    }

    @PostMapping("/query/orderRate")
    @ApiOperation("根据商户获取商户订单指标")
    public RestResponse<MerchantOrderRateRespDto> getOrderRate(@RequestBody MerchantOrderReqDto reqDto) {

        MerchantOrderRateRespDto rate = service.getOrderRate(reqDto.getMerchantCode());
        RestResponse<MerchantOrderRateRespDto> response = RestResponse.buildSuccessResponse(rate);

        return response;
    }

    @PostMapping("/query/more/orderRate")
    @ApiOperation("根据商户列表获取商户订单指标")
    public RestResponse<List<MerchantOrderRateRespDto>> getOrderRate(@RequestBody List<String> merchantCodes) {

        if (merchantCodes == null || merchantCodes.size() <= 0) {
            log.info("根据商户列表获取商户订单指标参数异常");
            throw new ApiException("根据商户列表获取商户订单指标参数异常");
        }

        List<MerchantOrderRateRespDto> orderRates = service.getOrderRates(merchantCodes);
        RestResponse<List<MerchantOrderRateRespDto>> listRestResponse = RestResponse.buildSuccessResponse(orderRates);

        return listRestResponse;
    }

    @PostMapping("/query/mainBusinessInfo")
    @ApiOperation("根据商户获取主经营数据")
    public RestResponse<MerchantBussinessMainRespDto> getMainBusinessInfo(@RequestBody MerchantBussinessMainReqDto reqDto) {
        MerchantBussinessMainRespDto info = service.getMainBusinessInfo(reqDto);
        RestResponse<MerchantBussinessMainRespDto> response = RestResponse.buildSuccessResponse(info);
        return response;
    }


    @PostMapping("/query/classBusinessInfo")
    @ApiOperation("根据类目获取经营数据")
    public RestResponse<MerchantBussinessClassRespDto> getClassBusinessInfo(@RequestBody MerchantBussinessClassReqDto reqDto) {

        MerchantBussinessClassRespDto info = service.getClassBusinessInfo(reqDto);
        RestResponse<MerchantBussinessClassRespDto> response = RestResponse.buildSuccessResponse(info);

        return response;
    }


    @PostMapping("/query/modelBusinessInfo")
    @ApiOperation("根据型号获取平台top10型号")
    public RestResponse<List<MerchantBussinessModelRespDto>> getModelBusinessInfo(@RequestBody MerchantBussinessModelReqDto reqDto) {
        List<MerchantBussinessModelRespDto> info = service.getModelBusinessInfo(reqDto);
        RestResponse<List<MerchantBussinessModelRespDto>> response = RestResponse.buildSuccessResponse(info);
        return response;
    }

/*
    @PostMapping("/query/deliveryRate")
    @ApiOperation("根据商户获取商户一手发货率")
    public RestResponse<MerchantRateRespDto> getNewDeliveryRate(@RequestBody MerchantOrderReqDto reqDto) {

        MerchantRateRespDto rate = service.getNewDeliveryRate(reqDto.getMerchantCode());
        RestResponse<MerchantRateRespDto> response = RestResponse.buildSuccessResponse(rate);

        return response;
    }
*/


    @PostMapping("/query/ClassInfo")
    @ApiOperation("根据商户获取获取类目维度列表")
    public RestResponse<List<MerchantBussinessMainClassRespDto>> getClassInfo(@RequestBody MerchantBussinessMainReqDto reqDto) {
        List<MerchantBussinessMainClassRespDto> info = service.getClassInfo(reqDto);
        RestResponse<List<MerchantBussinessMainClassRespDto>> response = RestResponse.buildSuccessResponse(info);
        return response;
    }

    @PostMapping("/query/getRiskRate")
    @ApiOperation("根据商户获取风控维度列表")
    public RestResponse<List<MerchantBussinessMainRiskRespDto>> getRiskRate(@RequestBody MerchantBussinessMainReqDto reqDto) {
        List<MerchantBussinessMainRiskRespDto> rate = service.getRiskRate(reqDto);
        RestResponse<List<MerchantBussinessMainRiskRespDto>> response = RestResponse.buildSuccessResponse(rate);
        return response;
    }

    @PostMapping("/query/getMainClassOrdRate")
    @ApiOperation("根据商户获取订单比率列表")
    public RestResponse<MerchantBussinessMainRateRespDto> getMainClassOrdRate(@RequestBody MerchantBussinessMainReqDto reqDto) {
        MerchantBussinessMainRateRespDto rate = service.getMainClassOrdRate(reqDto);
        RestResponse<MerchantBussinessMainRateRespDto> response = RestResponse.buildSuccessResponse(rate);
        return response;
    }

    @PostMapping("/query/isHasPhoneClass")
    @ApiOperation("是否手机品类")
    public RestResponse<Boolean> isHasPhoneClass(@RequestBody MerchantBussinessMainReqDto reqDto) {
        Boolean rate = service.isHasPhoneClass(reqDto);
        RestResponse<Boolean> response = RestResponse.buildSuccessResponse(rate);
        return response;
    }

    @PostMapping("/query/getTop10ByMerchant")
    @ApiOperation("获取店铺topic10商品")
    public RestResponse<List<MerchantBussinessMainModelRespDto>> getTop10ByMerchant(@RequestBody MerchantBussinessMainReqDto reqDto) {
        List<MerchantBussinessMainModelRespDto> list = service.getTop10ByMerchant(reqDto);
        RestResponse<List<MerchantBussinessMainModelRespDto>> response = RestResponse.buildSuccessResponse(list);
        return response;
    }

}
