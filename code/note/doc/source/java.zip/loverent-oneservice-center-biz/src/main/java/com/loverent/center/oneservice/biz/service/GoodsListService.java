package com.loverent.center.oneservice.biz.service;

import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public interface GoodsListService {
    //首页热租榜数据
    ResultPager<List<GoodsFirstPageHostListResDto>> getGoodsHostListInfo(@RequestBody GoodsFirstPageListReqDto reqDto);

    //首页新品榜数据
    ResultPager<List<GoodsFirstPageNewListResDto>> getGoodsNewListInfo(@RequestBody GoodsFirstPageListReqDto reqDto);

    //首页降价榜信息
    ResultPager<List<GoodsFirstPagePriceReductionListResDto>> getGoodsPriceReductionList(@RequestBody GoodsFirstPageListReqDto reqDto);



    List<GoodsOrderHotListResDto> getManualGoodsPageHotList (@RequestBody GoodsOrderListReqDto reqDto );

    List<GoodsOrderNewListResDto>  getManualGoodsPageNewList(@RequestBody GoodsOrderListReqDto reqDto );

    List<GoodsOrderPriceReductionListResDto> getManualGoodsPagepriceReductionList(@RequestBody GoodsOrderListReqDto reqDto );


    //首页榜单类目信息
    List<GoodsFirstPageListCateResDto> getGoodsListCate(@RequestBody GoodsFirstPageListCateReqDto reqDto);

    //首页瀑布流商品信息
    List<GoodsFirstPageWaterfallListResDto> getWaterfallList(@RequestBody GoodsFirstPageWaterfallListReqDto reqDto);

    List<GoodsRecommendListResDto> getListMoreRankGoods(@RequestBody GoodsRecommendListReqDto reqDto);


    List<BigDataRankGoodsTop50RespDto> geteWaterfallGoodsListInfo(@RequestBody BigDataRankGoodsTop50ReqDto reqDto);



}
