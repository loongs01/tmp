package com.loverent.center.oneservice.biz.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import com.loverent.center.oneservice.biz.constant.ListConstant;
import com.loverent.center.oneservice.biz.dao.mapper.GoodsListMapper;
import com.loverent.center.oneservice.biz.service.GoodsListService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.math.BigInteger;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
@Slf4j
public class GoodsHotServiceImpl implements GoodsListService {

    @Autowired
    GoodsListMapper goodsListMapper;
   //热租榜单数据
    @Override
    public ResultPager<List<GoodsFirstPageHostListResDto>> getGoodsHostListInfo(GoodsFirstPageListReqDto reqDto) {
        PageInfo<List<GoodsFirstPageHostListResDto>> pageInfo = PageHelper.startPage(reqDto.getCurrPage(), reqDto.getPageSize()).doSelectPageInfo(()
                -> goodsListMapper.getGoodsHotList(reqDto.getChannelNo(), reqDto.getCatePageLv1Id(),reqDto.getGoodsCode(),reqDto.getGoodsTitle(),reqDto.getSpuCode()));
        return new ResultPager<>((int) pageInfo.getTotal(), reqDto.getCurrPage(), reqDto.getPageSize(), pageInfo.getList());
    }
   //新品榜单数据
    @Override
    public ResultPager<List<GoodsFirstPageNewListResDto>> getGoodsNewListInfo(GoodsFirstPageListReqDto reqDto) {
        PageInfo<List<GoodsFirstPageNewListResDto>> pageInfo = PageHelper.startPage(reqDto.getCurrPage(), reqDto.getPageSize()).doSelectPageInfo(()
                -> goodsListMapper.getGoodsNewList(reqDto.getChannelNo(), reqDto.getCatePageLv1Id(),reqDto.getGoodsCode(),reqDto.getGoodsTitle(),reqDto.getSpuCode()));
        return new ResultPager<>((int) pageInfo.getTotal(), reqDto.getCurrPage(), reqDto.getPageSize(), pageInfo.getList());
    }
    //降价榜单数据
    @Override
    public ResultPager<List<GoodsFirstPagePriceReductionListResDto>> getGoodsPriceReductionList(GoodsFirstPageListReqDto reqDto) {
        PageInfo<List<GoodsFirstPagePriceReductionListResDto>> pageInfo = PageHelper.startPage(reqDto.getCurrPage(), reqDto.getPageSize()).doSelectPageInfo(()
                -> goodsListMapper.getGoodsPriceReductionList(reqDto.getChannelNo(), reqDto.getCatePageLv1Id(),reqDto.getGoodsCode(),reqDto.getGoodsTitle(),reqDto.getSpuCode()));
        return new ResultPager<>((int) pageInfo.getTotal(), reqDto.getCurrPage(), reqDto.getPageSize(), pageInfo.getList());
    }



    @Override
    public List<GoodsOrderHotListResDto> getManualGoodsPageHotList(GoodsOrderListReqDto reqDto) {
        return goodsListMapper.getManualGoodsPageHotList(reqDto.getChannelNo(),reqDto.getGoodsCode());
    }

    @Override
    public List<GoodsOrderNewListResDto> getManualGoodsPageNewList(GoodsOrderListReqDto reqDto) {
        return goodsListMapper.getManualGoodsPageNewList(reqDto.getChannelNo(),reqDto.getGoodsCode());
    }


    @Override
    public List<GoodsOrderPriceReductionListResDto> getManualGoodsPagepriceReductionList(GoodsOrderListReqDto reqDto) {
        return goodsListMapper.getManualGoodsPagepriceReductionList(reqDto.getChannelNo(),reqDto.getGoodsCode());
    }



    @Override
    public List<GoodsFirstPageListCateResDto> getGoodsListCate(GoodsFirstPageListCateReqDto reqDto) {
        List<GoodsFirstPageListCateResDto> goodsHotListCate = goodsListMapper.getGoodsListCate(reqDto.getChannelNo());
        return goodsHotListCate;
    }



    @Override
    public List<GoodsFirstPageWaterfallListResDto> getWaterfallList(GoodsFirstPageWaterfallListReqDto reqDto) {
        return goodsListMapper.getWaterfallList(reqDto.getChannelNo(),reqDto.getListRk(),reqDto.getGoodsCode());
    }


    @Override
    public List<GoodsRecommendListResDto> getListMoreRankGoods(GoodsRecommendListReqDto reqDto) {
        List<GoodsRecommendListResDto> newListMore=new ArrayList<>();
        List<GoodsRecommendListResDto> newListMoreRankGoodsCate=new ArrayList<>();
        List<GoodsRecommendListResDto> hotListMoreRankGoodsCate=new ArrayList<>();
        List<GoodsRecommendListResDto> priceReductionListMoreRankGoodsCate=new ArrayList<>();

        List<GoodsRecommendListPageReqDto> goodsRecommendListPageReqDto = reqDto.getGoodsRecommendListPageReqDto();
        ArrayList<String> newNo = new ArrayList<>();
        ArrayList<String> hot = new ArrayList<>();
        ArrayList<String> priceDown = new ArrayList<>();
        if(goodsRecommendListPageReqDto!=null && goodsRecommendListPageReqDto.size()>0){
            for (int i = 0; i < goodsRecommendListPageReqDto.size(); i++) {
                GoodsRecommendListPageReqDto goodsRecommendList = goodsRecommendListPageReqDto.get(i);
                if("newon".equals(goodsRecommendList.getRankType())){
                    newNo.add(goodsRecommendList.getCatePageLv1Id());
                } else if ("hot".equals(goodsRecommendList.getRankType())) {
                    hot.add(goodsRecommendList.getCatePageLv1Id());
                }else if ("pricedown".equals(goodsRecommendList.getRankType())) {
                    priceDown.add(goodsRecommendList.getCatePageLv1Id());
                }

            }
        }
        if(newNo!=null && newNo.size()>0) {
            newListMoreRankGoodsCate=goodsListMapper.getNewListMoreRankGoodsCate(reqDto.getChannelNo(), newNo);
            List<GoodsRecommendListGoodsReqDto> newListMoreRankGoods = goodsListMapper.getNewListMoreRankGoods(reqDto.getChannelNo(), newNo);
            Map<BigInteger, List<GoodsRecommendListGoodsReqDto>> collect = newListMoreRankGoods.stream().collect(Collectors.groupingBy(GoodsRecommendListGoodsReqDto::getCatePageLv1Id));
            if (newListMoreRankGoodsCate != null && newListMoreRankGoodsCate.size() > 0) {
                for (int i = 0; i < newListMoreRankGoodsCate.size(); i++) {
                    BigInteger catePageLv1Id = newListMoreRankGoodsCate.get(i).getCatePageLv1Id();
                    newListMoreRankGoodsCate.get(i).setGoodsInfo(collect.get(catePageLv1Id));
                }
            }
        }

        if(hot!=null && hot.size()>0) {
            hotListMoreRankGoodsCate = goodsListMapper.getHotListMoreRankGoodsCate(reqDto.getChannelNo(), hot);
            List<GoodsRecommendListGoodsReqDto> hotListMoreRankGoods = goodsListMapper.getHotListMoreRankGoods(reqDto.getChannelNo(), hot);
            Map<BigInteger, List<GoodsRecommendListGoodsReqDto>> hotCollect = hotListMoreRankGoods.stream().collect(Collectors.groupingBy(GoodsRecommendListGoodsReqDto::getCatePageLv1Id));
            if (hotListMoreRankGoodsCate != null && hotListMoreRankGoodsCate.size() > 0) {
                for (int i = 0; i < hotListMoreRankGoodsCate.size(); i++) {
                    BigInteger catePageLv1Id = hotListMoreRankGoodsCate.get(i).getCatePageLv1Id();
                    hotListMoreRankGoodsCate.get(i).setGoodsInfo(hotCollect.get(catePageLv1Id));

                }
            }
        }
        if(priceDown!=null && priceDown.size()>0) {
             priceReductionListMoreRankGoodsCate = goodsListMapper.getPriceReductionListMoreRankGoodsCate(reqDto.getChannelNo(), priceDown);
            List<GoodsRecommendListGoodsReqDto> priceListMoreRankGoods = goodsListMapper.getPriceReductionListMoreRankGoods(reqDto.getChannelNo(), priceDown);
            Map<BigInteger, List<GoodsRecommendListGoodsReqDto>> priceCollect = priceListMoreRankGoods.stream().collect(Collectors.groupingBy(GoodsRecommendListGoodsReqDto::getCatePageLv1Id));
            if (priceReductionListMoreRankGoodsCate != null && priceReductionListMoreRankGoodsCate.size() > 0) {
                for (int i = 0; i < priceReductionListMoreRankGoodsCate.size(); i++) {
                    BigInteger catePageLv1Id = priceReductionListMoreRankGoodsCate.get(i).getCatePageLv1Id();
                    priceReductionListMoreRankGoodsCate.get(i).setGoodsInfo(priceCollect.get(catePageLv1Id));


                }
            }
        }

            if(newListMoreRankGoodsCate!=null && newListMoreRankGoodsCate.size()>0){
                newListMore.addAll(newListMoreRankGoodsCate);
            }

            if(hotListMoreRankGoodsCate!=null && hotListMoreRankGoodsCate.size()>0){
                newListMore.addAll(hotListMoreRankGoodsCate);
            }
            if(priceReductionListMoreRankGoodsCate!=null && priceReductionListMoreRankGoodsCate.size()>0){
                newListMore.addAll(priceReductionListMoreRankGoodsCate);
            }

return newListMore;

    }

    @Override
    public List<BigDataRankGoodsTop50RespDto>  geteWaterfallGoodsListInfo(BigDataRankGoodsTop50ReqDto reqDto) {
        List<BigDataRankGoodsTop50BodyReqDto> catePageLv1IdRankTypes = reqDto.getCatePageLv1IdRankTypes();
        List<BigDataRankGoodsTop50RespDto> newListMoreRankGoodsCate=new ArrayList<>();

        ArrayList<Long> newNo = new ArrayList<>();
        ArrayList<Long> hot = new ArrayList<>();
        ArrayList<Long> priceDown = new ArrayList<>();
        if(catePageLv1IdRankTypes!=null && catePageLv1IdRankTypes.size()>0){
            for (int i = 0; i < catePageLv1IdRankTypes.size(); i++) {
                BigDataRankGoodsTop50BodyReqDto goodsFirstPageWaterfallListCateReqDto1 = catePageLv1IdRankTypes.get(i);
                if(goodsFirstPageWaterfallListCateReqDto1.getRankType().equals(ListConstant.HOT_STR)){
                    hot.add(goodsFirstPageWaterfallListCateReqDto1.getCatePageLv1Id());
                } else if (goodsFirstPageWaterfallListCateReqDto1.getRankType().equals(ListConstant.NEW_STR)) {
                    newNo.add(goodsFirstPageWaterfallListCateReqDto1.getCatePageLv1Id());
                }else if (goodsFirstPageWaterfallListCateReqDto1.getRankType().equals(ListConstant.DROP_STR)) {
                    priceDown.add(goodsFirstPageWaterfallListCateReqDto1.getCatePageLv1Id());
                }

            }
        }

        if(newNo!=null && newNo.size()>0) {

            List<BigDataRankGoodsTop50RespDto> bigDataRankGoodsTop50RespDtos = goodsListMapper.geteWaterfallGoodsNewListInfo(reqDto.getChannelNo(), newNo);

            if(bigDataRankGoodsTop50RespDtos!=null && bigDataRankGoodsTop50RespDtos.size()>0) {
                newListMoreRankGoodsCate.addAll(bigDataRankGoodsTop50RespDtos);
            }
        }
        if(hot!=null && hot.size()>0) {
            List<BigDataRankGoodsTop50RespDto> bigDataRankGoodsTop50RespDtos = goodsListMapper.geteWaterfallGoodsHotListInfo(reqDto.getChannelNo(), hot);
            if(bigDataRankGoodsTop50RespDtos!=null && bigDataRankGoodsTop50RespDtos.size()>0) {
                newListMoreRankGoodsCate.addAll(bigDataRankGoodsTop50RespDtos);
            }
        }
        if(priceDown!=null && priceDown.size()>0) {
            List<BigDataRankGoodsTop50RespDto> bigDataRankGoodsTop50RespDtos = goodsListMapper.geteWaterfallGoodsDropListInfo(reqDto.getChannelNo(), priceDown);
            if(bigDataRankGoodsTop50RespDtos!=null && bigDataRankGoodsTop50RespDtos.size()>0) {
                newListMoreRankGoodsCate.addAll(bigDataRankGoodsTop50RespDtos);
            }

        }


        return newListMoreRankGoodsCate;
    }


}
