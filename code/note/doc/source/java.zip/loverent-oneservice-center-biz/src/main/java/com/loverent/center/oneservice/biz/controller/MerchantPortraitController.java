package com.loverent.center.oneservice.biz.controller;

import com.alibaba.fastjson.JSON;
import com.loverent.center.oneservice.api.dto.request.MerchantPortraitReqDto;
import com.loverent.center.oneservice.api.dto.response.MerchantPortraitRespDto;
import com.loverent.center.oneservice.biz.service.MerchantBusinessService;
import com.loverent.center.oneservice.biz.service.MerchantPortraitService;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * 商家画像相关
 */
@Api(tags = "商户画像相关接口")
@RestController
@RequestMapping("/v1/query/merchantPortrait")
@Slf4j
public class MerchantPortraitController {


    @Autowired
    private MerchantPortraitService merchantPortraitService;

    @ApiOperation(value = "批量根据商户编码查询商户画像标签", notes = "批量根据商户编码查询商户画像标签")
    @PostMapping(value = "/batchQueryPortrait")
    public RestResponse<List<MerchantPortraitRespDto>> pageQuery(@RequestBody MerchantPortraitReqDto pageQuery) throws Exception {
        RestResponse responseResult = null;
        List<MerchantPortraitRespDto> respDtos = merchantPortraitService.batchQueryPortraitMerge(pageQuery.getMerChantCode());
        responseResult = RestResponse.buildSuccessResponse(respDtos);
        log.info("批量根据商户编码查询商户画像标签 参数{},结果{}", JSON.toJSONString(pageQuery), JSON.toJSONString(responseResult));
        return responseResult;
    }

}
