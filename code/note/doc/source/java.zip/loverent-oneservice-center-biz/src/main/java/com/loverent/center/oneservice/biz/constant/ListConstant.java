package com.loverent.center.oneservice.biz.constant;

import io.swagger.annotations.ApiModelProperty;

/**
 * @author zhoutw
 * @date 2023年08月25日 10:13
 */
public class ListConstant {
    //热租榜
    public static final Long HOT = 1L;
    //新品榜
    public static final Long NEW = 2L;
    //降价榜
    public final static Long DROP = 3L;

    public static final String HOT_STR = "hot";
    //新品榜
    public static final String NEW_STR = "newon";
    //降价榜
    public final static String DROP_STR = "pricedown";

}
