package com.loverent.center.oneservice.biz.service.impl;

import com.loverent.center.oneservice.api.dto.request.MerchantBussinessClassReqDto;
import com.loverent.center.oneservice.api.dto.request.MerchantBussinessMainReqDto;
import com.loverent.center.oneservice.api.dto.request.MerchantBussinessModelReqDto;
import com.loverent.center.oneservice.api.dto.request.OptClassListReqDto;
import com.loverent.center.oneservice.api.dto.response.*;
import com.loverent.center.oneservice.biz.dao.mapper.*;
import com.loverent.center.oneservice.biz.service.MerchantBusinessService;
import com.loverent.center.oneservice.biz.utils.StatTimeUtil;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.ApiOperation;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import javax.validation.constraints.NotEmpty;
import java.util.ArrayList;
import java.util.List;

/**
 * @author zhoutw
 * @date 2023年12月07日 18:27
 */
@Service
@Slf4j
public class MerchantBusinessServiceImpl implements MerchantBusinessService {

    @Autowired
    MerchantBusinessMapper merchantBusinessMapper;


    @Autowired
    MoptMhtCateTdMapper moptMhtCateTdMapper;

    @Autowired
    MoptUsrRiskMhtTdMapper MoptUsrRiskMhtTdMapper;

    @Autowired
    MoptOutboundModelTop10MhtDaMapper modelTop10MhtDaMapper;

    @Autowired
    MoptApplyModelTop10CateDaMapper platformModelTop10CateDaMapper;

    @Override
    public MerchantOrderRateRespDto getOrderRate(final String merchantCode) {

        String time = merchantBusinessMapper.getStatTime(merchantCode);
        log.info("getOrderRate获取最大统计时间：{}", time);
        MerchantOrderRateRespDto rate = merchantBusinessMapper.getOrderRate(merchantCode, time);
        if(rate == null){
            rate=new MerchantOrderRateRespDto();
            rate.setMerchantCode(merchantCode);
        }

        return rate;
    }

    @Override
    public List<MerchantOrderRateRespDto> getOrderRates(List<String> merchantCodes) {

        String time = merchantBusinessMapper.getStatTime(merchantCodes.get(0));
        log.info("getOrderRate获取最大统计时间：{}", time);
        List<MerchantOrderRateRespDto> resluts = merchantBusinessMapper.getOrderRateBymerchantCodes(merchantCodes, time);
        if(resluts == null){
            resluts = new ArrayList<MerchantOrderRateRespDto>();
        }

        return resluts;
    }

    @Override
    public List<OptClassRespDto> getOptClass() {
        return merchantBusinessMapper.getOptClass();
    }

    @Override
    public MerchantBussinessMainRespDto getMainBusinessInfo(final MerchantBussinessMainReqDto reqDto) {

        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        log.info("getMainBusinessInfo获取统计时间：{}---{}", statTime, endTime);
        //获取类目维度列表
        List<MerchantBussinessMainClassRespDto> mainClassRespDtos = moptMhtCateTdMapper.getMainClassInfo(merchantCode, statTime, endTime);

        //获取用户风险维度列表
        List<MerchantBussinessMainRiskRespDto> riskRateDtos = MoptUsrRiskMhtTdMapper.getRiskRate(merchantCode, statTime, endTime);

        //获取订单比率
        MerchantBussinessMainRateRespDto ordRateDto = moptMhtCateTdMapper.getMainClassOrdRate(merchantCode, statTime, endTime);
        if(ordRateDto == null ){
            ordRateDto = new MerchantBussinessMainRateRespDto();
        }
        Long phoneClassCount = moptMhtCateTdMapper.isHasPhoneClass(merchantCode, statTime, endTime);
        boolean isHasPhoneClass = phoneClassCount != null && phoneClassCount>0 ? true:false;
        ordRateDto.setHasPhoneClass(isHasPhoneClass);

        //热门top10
        List<MerchantBussinessMainModelRespDto> topModelDtos = modelTop10MhtDaMapper.getTop10ByMerchant(merchantCode, statTime, endTime);

        MerchantBussinessMainRespDto dto = new MerchantBussinessMainRespDto();
        dto.setMerchantCode(reqDto.getMerchantCode());
        dto.setStatStartDate(reqDto.getStatStartDate());
        dto.setStatEndDate(reqDto.getStatEndDate());
        dto.setMainClassRespDtos(mainClassRespDtos);
        dto.setMainRiskRespDtos(riskRateDtos);
        dto.setMainRateRespDtos(ordRateDto);
        dto.setMainModelRespDtos(topModelDtos);
        return dto;
    }

    @Override
    public MerchantBussinessClassRespDto getClassBusinessInfo(final MerchantBussinessClassReqDto reqDto) {
        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        MerchantBussinessClassRespDto dto = moptMhtCateTdMapper.getRentRateByClassName
                (merchantCode, statTime, endTime, reqDto.getOptClassCode(), reqDto.getOptClassName());

        if(dto== null){
            dto= new MerchantBussinessClassRespDto();
            dto.setOptClassCode(reqDto.getOptClassCode());
        }


        return dto;
    }

    @Override
    public List<MerchantBussinessModelRespDto> getModelBusinessInfo(final MerchantBussinessModelReqDto reqDto) {

        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        List<MerchantBussinessModelRespDto> total = platformModelTop10CateDaMapper.getTop10Total
                (statTime, endTime,
                        reqDto.getOptClassCode(), reqDto.getOptClassName());
        return total;
    }


    @Override
    public List<OptClassRespDto> getOptClass(OptClassListReqDto reqDto) {
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        return moptMhtCateTdMapper.getOptClass(reqDto.getMerchantCode(),
                statTime,
                endTime);
    }

    @Override
    public MerchantRateRespDto getNewDeliveryRate(final String merchantCode) {
        MerchantRateRespDto rate = moptMhtCateTdMapper.getNewDeliveryRate(merchantCode);
        if(rate == null ){
            rate=new MerchantRateRespDto(merchantCode,0.00D);
        }
        return rate;
    }

    /**
     * 根据商户获取类目维度列表
     *
     * @param reqDto
     * @return
     */
    @Override
    public List<MerchantBussinessMainClassRespDto> getClassInfo(final MerchantBussinessMainReqDto reqDto) {
        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        log.info("getMainClassInfo获取{}统计时间：{}---{}", merchantCode,statTime, endTime);
        //获取类目维度列表
        List<MerchantBussinessMainClassRespDto> infoList = moptMhtCateTdMapper.getMainClassInfo(merchantCode, statTime, endTime);
        if(infoList == null){
            infoList = new ArrayList<>();
        }
        return infoList;

    }

    /**
     * 根据商户获取风控维度列表
     *
     * @param reqDto
     * @return
     */
    @Override
    public  List<MerchantBussinessMainRiskRespDto> getRiskRate(final MerchantBussinessMainReqDto reqDto) {
        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        log.info("getMainClassInfo获取{}统计时间：{}---{}", merchantCode,statTime, endTime);

        //获取用户风险维度列表
        List<MerchantBussinessMainRiskRespDto> rateList = MoptUsrRiskMhtTdMapper.getRiskRate(merchantCode, statTime, endTime);
        if(rateList == null){
            rateList = new ArrayList<>();
        }
        return rateList;

    }

    /**
     * 根据商户获取订单比率列表
     *
     * @param reqDto
     * @return
     */
    @Override
    public MerchantBussinessMainRateRespDto getMainClassOrdRate(final MerchantBussinessMainReqDto reqDto) {
        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        log.info("getMainClassInfo获取{}统计时间：{}---{}", merchantCode,statTime, endTime);
        //获取订单比率
        MerchantBussinessMainRateRespDto ordRateDto = moptMhtCateTdMapper.getMainClassOrdRate(merchantCode, statTime, endTime);
        if(ordRateDto == null ){
            ordRateDto = new MerchantBussinessMainRateRespDto();
        }
        return ordRateDto;
    }

    /**
     * 根据商户获取订单比率列表
     *
     * @param reqDto
     * @return
     */
    @Override
    public Boolean isHasPhoneClass(final MerchantBussinessMainReqDto reqDto) {
        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        log.info("getMainClassInfo获取{}统计时间：{}---{}", merchantCode,statTime, endTime);

        Long phoneClassCount = moptMhtCateTdMapper.isHasPhoneClass(merchantCode, statTime, endTime);
        boolean isHasPhoneClass = phoneClassCount != null && phoneClassCount>0 ? true:false;

        return isHasPhoneClass;
    }

    /**
     * 获取店铺topic10商品
     *
     * @param reqDto
     * @return
     */
    @Override
    public List<MerchantBussinessMainModelRespDto> getTop10ByMerchant(final MerchantBussinessMainReqDto reqDto) {
        String merchantCode = reqDto.getMerchantCode();
        String statTime = StatTimeUtil.parseStatTime(reqDto.getStatStartDate());
        String endTime = StatTimeUtil.parseStatTime(reqDto.getStatEndDate());
        log.info("getMainClassInfo获取{}统计时间：{}---{}", merchantCode,statTime, endTime);
        //热门top10
        List<MerchantBussinessMainModelRespDto> topModelDtos = modelTop10MhtDaMapper.getTop10ByMerchant(merchantCode, statTime, endTime);
        if(topModelDtos == null ){
            topModelDtos = new ArrayList<>();
        }
        return topModelDtos;
    }
}
