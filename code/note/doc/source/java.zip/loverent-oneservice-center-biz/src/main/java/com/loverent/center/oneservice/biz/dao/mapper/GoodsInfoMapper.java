package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.GoodsInfoCountResDto;
import com.loverent.center.oneservice.api.dto.response.GoodsInfoResDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.dao.mapper
 * @ClassName GoodsInfoMapper
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  13:36
 */
@Mapper
@Repository
public interface GoodsInfoMapper {

    List<GoodsInfoResDto> getGoodsInfo(@Param("typeCodeList") List<String> typeCodeList, @Param("brandCodeList") List<String> brandCodeList
            , @Param("modelCodeList") List<String> modelCodeList, @Param("merchantTypeList") List<Integer> merchantTypeList, @Param("merchantCodeList") List<String> merchantCodeList
            , @Param("leaseMoldCodeList") List<String> leaseMoldCodeList, @Param("newConfigIdList") List<Integer> newConfigIdList
            , @Param("leaseTermTypeList") List<Integer> leaseTermTypeList
            , @Param("discountTypeList") List<Integer> discountTypeList
            , @Param("cycleDays1") Integer cycleDays1, @Param("cycleDays2") Integer cycleDays2, @Param("cycleDays3") Integer cycleDays3
            , @Param("weight1") Integer weight1, @Param("weight2") Integer weight2, @Param("weight3") Integer weight3
    );

    List<GoodsInfoCountResDto> getGoodsInfoCount(@Param("typeCodeList") List<String> typeCodeList, @Param("brandCodeList") List<String> brandCodeList
            , @Param("modelCodeList") List<String> modelCodeList, @Param("merchantTypeList") List<Integer> merchantTypeList, @Param("merchantCodeList") List<String> merchantCodeList
            , @Param("leaseMoldCodeList") List<String> leaseMoldCodeList, @Param("newConfigIdList") List<Integer> newConfigIdList
            , @Param("leaseTermTypeList") List<Integer> leaseTermTypeList
            , @Param("discountTypeList") List<Integer> discountTypeList
    );
}
