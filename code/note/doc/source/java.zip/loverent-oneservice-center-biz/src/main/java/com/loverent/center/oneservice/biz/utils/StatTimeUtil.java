package com.loverent.center.oneservice.biz.utils;

import java.text.SimpleDateFormat;
import java.util.Date;

/**
 * @author zhoutw
 * @date 2023年12月08日 14:11
 */
public class StatTimeUtil {

    /**
     * 转换日期格式
     * @param time
     * @return
     */
    public static String parseStatTime(Date time){
        SimpleDateFormat sdf = new SimpleDateFormat("yyyyMMdd");
        String format = sdf.format(time);
        return  format;
    }
}
