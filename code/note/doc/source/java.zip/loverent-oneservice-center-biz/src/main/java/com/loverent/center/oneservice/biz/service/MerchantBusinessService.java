package com.loverent.center.oneservice.biz.service;

import com.loverent.center.oneservice.api.dto.request.MerchantBussinessClassReqDto;
import com.loverent.center.oneservice.api.dto.request.MerchantBussinessMainReqDto;
import com.loverent.center.oneservice.api.dto.request.MerchantBussinessModelReqDto;
import com.loverent.center.oneservice.api.dto.request.OptClassListReqDto;
import com.loverent.center.oneservice.api.dto.response.*;
import org.apache.ibatis.annotations.Param;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

public interface MerchantBusinessService {
    MerchantOrderRateRespDto getOrderRate(String merchantCode);

    public List<MerchantOrderRateRespDto> getOrderRates(List<String> merchantCodes);

    MerchantBussinessMainRespDto getMainBusinessInfo(@RequestBody MerchantBussinessMainReqDto reqDto);


    MerchantBussinessClassRespDto getClassBusinessInfo(final MerchantBussinessClassReqDto reqDto);


    List<MerchantBussinessModelRespDto> getModelBusinessInfo(@RequestBody MerchantBussinessModelReqDto reqDto);

    public List<OptClassRespDto> getOptClass();

    List<OptClassRespDto> getOptClass(OptClassListReqDto reqDto);


    MerchantRateRespDto getNewDeliveryRate(String merchantCode);

    /**
     * 根据商户获取类目维度列表
     * @param reqDto
     * @return
     */
    List<MerchantBussinessMainClassRespDto> getClassInfo(MerchantBussinessMainReqDto reqDto);


    /**
     * 根据商户获取风控维度列表
     * @param reqDto
     * @return
     */
    List<MerchantBussinessMainRiskRespDto> getRiskRate(MerchantBussinessMainReqDto reqDto);


    /**
     * 根据商户获取订单比率列表
     * @param reqDto
     * @return
     */
    MerchantBussinessMainRateRespDto getMainClassOrdRate(MerchantBussinessMainReqDto reqDto);



    /**
     * 根据商户获取订单比率列表
     * @param reqDto
     * @return
     */
    Boolean isHasPhoneClass(MerchantBussinessMainReqDto reqDto);


    /**
     * 获取店铺topic10商品
     * @param reqDto
     * @return
     */
    List<MerchantBussinessMainModelRespDto> getTop10ByMerchant(MerchantBussinessMainReqDto reqDto);
}
