package com.loverent.center.oneservice.biz.utils;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.utils
 * @ClassName GetSystemTime
 * @Author: lichaozhong
 * @CreateTime: 2024-05-09  15:37
 */
public class GetSystemTime {
    public static String getTime() {
        LocalDate yesterday = LocalDate.now().minusDays(1);
        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyyMMdd");
        String formattedDate = yesterday.format(formatter);
        System.out.println(formattedDate);
        return formattedDate;
    }
}
