package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MoptMhtCateTdMapper {

    List<MerchantBussinessMainClassRespDto> getMainClassInfo(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate);


    MerchantRateRespDto getNewDeliveryRate(@Param("merchantCode") String merchantCode);

    MerchantBussinessMainRateRespDto getMainClassOrdRate(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate);

    String getStatTime(@Param("merchantCode") String merchantCode);

    MerchantBussinessClassRespDto getRentRateByClassName(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate
            , @Param("optClassCode") String optClassCode, @Param("optClassName") String optClassName
         );



    List<OptClassRespDto>  getOptClass(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate
    );

    Long  isHasPhoneClass(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate
    );


}
