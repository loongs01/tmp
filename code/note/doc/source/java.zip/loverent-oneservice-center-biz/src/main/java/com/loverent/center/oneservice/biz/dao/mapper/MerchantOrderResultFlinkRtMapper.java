package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.MerchantPortraitRespDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/4/1 19:30
 */

@Mapper
@Repository
public interface MerchantOrderResultFlinkRtMapper {


    public List<MerchantPortraitRespDto> getMerchantRealTimeOrderResult(@Param("dt") String dt,@Param("merchantCodes") List<String> merchantCodes);



}
