package com.loverent.center.oneservice.biz.controller;

import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import com.loverent.center.oneservice.biz.service.GoodsListService;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

@Slf4j
@Api("商品榜单排名控制器")
@ApiModel(description = "商品榜单排名控制器")
@RestController
@RequestMapping("/data/goods")
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class GoodsListController {

    @Autowired
    GoodsListService service;


    @PostMapping("/query/hostList")
    @ApiOperation("获取热租榜单数据")
    public RestResponse<ResultPager<List<GoodsFirstPageHostListResDto>>> getGoodsPageHotList(@RequestBody GoodsFirstPageListReqDto reqDto ) {

        ResultPager<List<GoodsFirstPageHostListResDto>> goodsListInfo = service.getGoodsHostListInfo(reqDto);
        RestResponse<ResultPager<List<GoodsFirstPageHostListResDto>>> resultPagerRestResponse = RestResponse.buildSuccessResponse(goodsListInfo);
        return resultPagerRestResponse;
    }


    @PostMapping("/query/newList")
    @ApiOperation("获取新品榜单数据")
    public RestResponse<ResultPager<List<GoodsFirstPageNewListResDto>>> getGoodsPageNewList(@RequestBody GoodsFirstPageListReqDto reqDto ) {
        ResultPager<List<GoodsFirstPageNewListResDto>> goodsNewListInfo = service.getGoodsNewListInfo(reqDto);
        RestResponse<ResultPager<List<GoodsFirstPageNewListResDto>>> resultPagerRestResponse = RestResponse.buildSuccessResponse(goodsNewListInfo);
        return resultPagerRestResponse;
    }

    @PostMapping("/query/priceReductionList")
    @ApiOperation("获取降价榜单数据")
    public RestResponse<ResultPager<List<GoodsFirstPagePriceReductionListResDto>>> getGoodsPagepriceReductionList(@RequestBody GoodsFirstPageListReqDto reqDto ) {
        ResultPager<List<GoodsFirstPagePriceReductionListResDto>> goodsPagepriceReductionList = service.getGoodsPriceReductionList(reqDto);
        RestResponse<ResultPager<List<GoodsFirstPagePriceReductionListResDto>>> resultPagerRestResponse = RestResponse.buildSuccessResponse(goodsPagepriceReductionList);
        return resultPagerRestResponse;
    }


    @PostMapping("/query/hostListManual")
    @ApiOperation("获取人工干预热租榜单数据")
    public RestResponse<List<GoodsOrderHotListResDto>> getManualGoodsPageHotList(@RequestBody GoodsOrderListReqDto reqDto ) {
        List<GoodsOrderHotListResDto> manualGoodsPageHotList = service.getManualGoodsPageHotList(reqDto);
        RestResponse<List<GoodsOrderHotListResDto>> resultPagerRestResponse = RestResponse.buildSuccessResponse(manualGoodsPageHotList);
        return resultPagerRestResponse;
    }

    @PostMapping("/query/newListManual")
    @ApiOperation("获取人工干预新品榜单数据")
    public RestResponse<List<GoodsOrderNewListResDto>> getManualGoodsPageNewList(@RequestBody GoodsOrderListReqDto reqDto ) {
        List<GoodsOrderNewListResDto> manualGoodsPageNewList = service.getManualGoodsPageNewList(reqDto);
        RestResponse<List<GoodsOrderNewListResDto>> listRestResponse = RestResponse.buildSuccessResponse(manualGoodsPageNewList);
        return listRestResponse;
    }

    @PostMapping("/query/priceReductionListManual")
    @ApiOperation("获取人工干预降价榜单数据")
    public RestResponse<List<GoodsOrderPriceReductionListResDto>> getManualGoodsPagepriceReductionList(@RequestBody GoodsOrderListReqDto reqDto ) {
        List<GoodsOrderPriceReductionListResDto> manualGoodsPagepriceReductionList = service.getManualGoodsPagepriceReductionList(reqDto);
        RestResponse<List<GoodsOrderPriceReductionListResDto>> resultPagerRestResponse = RestResponse.buildSuccessResponse(manualGoodsPagepriceReductionList);
        return resultPagerRestResponse;
    }


    @PostMapping("/query/ListCate")
    @ApiOperation("获取榜单类目数据")
    public  RestResponse<List<GoodsFirstPageListCateResDto>> getGoodsListCate(@RequestBody GoodsFirstPageListCateReqDto reqDto) {
        List<GoodsFirstPageListCateResDto> goodsListCate = service.getGoodsListCate(reqDto);
        RestResponse<List<GoodsFirstPageListCateResDto>> listRestResponse = RestResponse.buildSuccessResponse(goodsListCate);
        return listRestResponse;
    }

    @PostMapping("/query/waterfallList")
    @ApiOperation("获取瀑布流榜单数据")
    public RestResponse<List<GoodsFirstPageWaterfallListResDto>> geteWaterfallList(@RequestBody GoodsFirstPageWaterfallListReqDto reqDto ) {
        List<GoodsFirstPageWaterfallListResDto> goodsFirstPageWaterfallListResDtos = service.getWaterfallList(reqDto);
        RestResponse<List<GoodsFirstPageWaterfallListResDto>> listRestResponse = RestResponse.buildSuccessResponse(goodsFirstPageWaterfallListResDtos);
        return listRestResponse;
    }

    @PostMapping("/query/listMoreRankGoods")
    @ApiOperation("获取更多榜单数据")
    RestResponse<List<GoodsRecommendListResDto>> getListMoreRankGoods(@RequestBody GoodsRecommendListReqDto reqDto){
        List<GoodsRecommendListResDto> listMoreRankGoods = service.getListMoreRankGoods(reqDto);
        RestResponse<List<GoodsRecommendListResDto>> listRestResponse = RestResponse.buildSuccessResponse(listMoreRankGoods);
        return listRestResponse;
    }




    @PostMapping("/query/listTop50ByCatePageLv1IdRankTypes")
    @ApiOperation("根据分类id-榜单类型获取前50商品")
    RestResponse<List<BigDataRankGoodsTop50RespDto>> listTop50ByCatePageLv1IdRankTypes(@RequestBody BigDataRankGoodsTop50ReqDto reqDto){
        List<BigDataRankGoodsTop50RespDto> bigDataRankGoodsTop50RespDtos = service.geteWaterfallGoodsListInfo(reqDto);
        RestResponse<List<BigDataRankGoodsTop50RespDto>> listRestResponse = RestResponse.buildSuccessResponse(bigDataRankGoodsTop50RespDtos);
        return listRestResponse;
    }



}




















