package com.loverent.center.oneservice.biz.service.impl;


import com.loverent.center.oneservice.api.dto.response.MerchantListResDto;
import com.loverent.center.oneservice.api.dto.response.MerchantPortraitRespDto;
import com.loverent.center.oneservice.biz.dao.mapper.MerchantOrderResultFlinkRtMapper;
import com.loverent.center.oneservice.biz.dao.mapper.MerchantOrderResultRtMapper;
import com.loverent.center.oneservice.biz.service.MerchantPortraitService;
import com.loverent.center.oneservice.biz.utils.StatTimeUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@Slf4j
public class MerchantPortraitServiceImpl implements MerchantPortraitService {

    @Autowired
    MerchantOrderResultRtMapper merchantOrderResultRtMapper;

    @Autowired
    MerchantOrderResultFlinkRtMapper flinkRtMapper;

    @Override
    public List<MerchantPortraitRespDto> batchQueryPortraitMerge(List<String> merchantCodeList) {
        String date = StatTimeUtil.parseStatTime(new Date());
        List<MerchantPortraitRespDto> result = new ArrayList<>();
        List<MerchantPortraitRespDto> orderResult = null;
        List<MerchantPortraitRespDto> flinkOrderResult = null;
        if (merchantCodeList != null && merchantCodeList.size() > 0) {

            flinkOrderResult = flinkRtMapper.getMerchantRealTimeOrderResult(date, merchantCodeList);
            //离线
            orderResult = merchantOrderResultRtMapper.getMerchantRealTimeOrderResult(date, merchantCodeList);
        }
        Map<String, MerchantPortraitRespDto> resultMap = null;
        Map<String, MerchantPortraitRespDto> flinkOrderMap = null;
        if(orderResult!=null){
            resultMap = orderResult.stream().collect(Collectors.toMap(MerchantPortraitRespDto::getMerchantCode, Function.identity(), (v1, v2) -> v1));
        }
        if(orderResult!=null){
            flinkOrderMap = flinkOrderResult.stream().collect(Collectors.toMap(MerchantPortraitRespDto::getMerchantCode, Function.identity(), (v1, v2) -> v1));
        }


        for (String merchant : merchantCodeList) {
            //两边不为空，哪个大取那个
            if ((flinkOrderMap != null && flinkOrderMap.size() > 0) &&(resultMap != null && resultMap.size() > 0)) {
                MerchantPortraitRespDto dto = new MerchantPortraitRespDto();
                MerchantPortraitRespDto mapEle = resultMap.get(merchant);
                MerchantPortraitRespDto flinkMapEle = flinkOrderMap.get(merchant);

                if(mapEle != null && flinkMapEle!=null){
                    Long total = mapEle.getTodayTotalRecOrder() != null?mapEle.getTodayTotalRecOrder():0L;
                    Long flinkTotal = flinkMapEle.getTodayTotalRecOrder() != null?flinkMapEle.getTodayTotalRecOrder():0L;
                    //谁大取数谁
                    if(flinkTotal>total){
                        log.info("{}两边不为空，flinkTotal大",merchant);
                        result.add(flinkMapEle);
                    }else{
                        log.info("{}两边不为空，total大",merchant);
                        result.add(mapEle);
                    }
                }else if(mapEle != null && flinkMapEle == null){
                    log.info("{}两边不为空，取mapEle",merchant);
                    result.add(mapEle);
                }else  if(mapEle == null && flinkMapEle != null){
                    log.info("{}两边不为空，取flinkMapEle",merchant);
                    result.add(flinkMapEle);
                }else{
                    dto.setMerchantCode(merchant);
                    dto.setTodayRecOrder(0L);
                    dto.setTodaySecRecOrder(0L);
                    dto.setTodayTotalRecOrder(0L);
                    result.add(dto);
                }

                //flink不为空，离线为空
            } else if((flinkOrderMap != null && flinkOrderMap.size() > 0) &&(resultMap == null || resultMap.size() <= 0)){
                log.info("{}flink不为空，离线为空",merchant);
                MerchantPortraitRespDto flinkMapEle = flinkOrderMap.get(merchant);
                if (flinkMapEle == null) {
                    MerchantPortraitRespDto dto = new MerchantPortraitRespDto();
                    dto.setMerchantCode(merchant);
                    dto.setTodayRecOrder(0L);
                    dto.setTodaySecRecOrder(0L);
                    dto.setTodayTotalRecOrder(0L);
                    result.add(dto);
                } else {
                    result.add(flinkMapEle);
                }
                //实时为空，离线不为空
            }else if((flinkOrderMap == null || flinkOrderMap.size() <= 0) &&(resultMap != null && resultMap.size() > 0)){
                log.info("{}实时为空，离线不为空",merchant);
                MerchantPortraitRespDto mapEle = resultMap.get(merchant);
                if (mapEle == null) {
                    MerchantPortraitRespDto dto = new MerchantPortraitRespDto();
                    dto.setMerchantCode(merchant);
                    dto.setTodayRecOrder(0L);
                    dto.setTodaySecRecOrder(0L);
                    dto.setTodayTotalRecOrder(0L);
                    result.add(dto);
                } else {
                    result.add(mapEle);
                }

            } else {
                log.info("{}两边为空取默认值",merchant);
                //两边为空取默认值
                MerchantPortraitRespDto dto = new MerchantPortraitRespDto();
                dto.setMerchantCode(merchant);
                dto.setTodayRecOrder(0L);
                dto.setTodaySecRecOrder(0L);
                dto.setTodayTotalRecOrder(0L);
                result.add(dto);

            }

        }
        return result;

    }
}
