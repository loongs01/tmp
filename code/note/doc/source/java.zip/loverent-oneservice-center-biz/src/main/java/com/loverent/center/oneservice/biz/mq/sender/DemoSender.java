package com.loverent.center.oneservice.biz.mq.sender;

import com.alibaba.fastjson.JSON;
import com.loverent.center.oneservice.biz.mq.registryvo.DemoRegistryVo;
import com.loverent.common.vo.MessageVo;
import com.loverent.mq.api.IMessageSender;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 消息发送示例
 *
 * @author yu.ce@foxmail.com
 * @version 1.0.0
 * @date  2019-11-25 16:16
 */
@Component
public class DemoSender {
	/*@Autowired
	private IMessageSender messageSender;

	@Resource
	private DemoRegistryVo demoUserRegistryVo;

	*//**
	 * 普通消息发送 示例
	 *
	 * @param reqDto
	 *//*
	public void sendMessage(DemoReqDto reqDto){
		MessageVo messageVo = new MessageVo();
		messageVo.setBizCode("demo_user");
		messageVo.setBizName("mq demo");
		messageVo.setMsgContent(JSON.toJSONString(reqDto));
		// 使用常量
		//messageSender.sendMessage(MQConstant.DEMO_USER_TOPIC, MQConstant.DEMO_USER_TAG , messageVo);
		// 使用nacos配置
		messageSender.sendMessage(demoUserRegistryVo.getTopic(), demoUserRegistryVo.getTag() , messageVo);
	}*/
}
