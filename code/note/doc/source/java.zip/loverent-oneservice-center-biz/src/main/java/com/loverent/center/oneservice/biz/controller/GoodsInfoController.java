package com.loverent.center.oneservice.biz.controller;

import com.loverent.center.oneservice.api.dto.request.GoodsInfoCountReqDto;
import com.loverent.center.oneservice.api.dto.request.GoodsInfoReqDto;

import com.loverent.center.oneservice.api.dto.response.GoodsInfoCountResDto;
import com.loverent.center.oneservice.api.dto.response.GoodsInfoResDto;

import com.loverent.center.oneservice.biz.dao.mapper.GoodsInfoMapper;
import com.loverent.center.oneservice.biz.service.GoodsInfoService;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.controller
 * @ClassName GoodsInfoController
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  11:59
 */


@Slf4j
@Api("商品信息控制器")
@ApiModel(description = "商品信息控制器")
@RestController
@RequestMapping("/data/goods")
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class GoodsInfoController {
    GoodsInfoService service;

    @PostMapping("/query/goodsinfo")
    @ApiOperation("获取商品池明细数据")
    public RestResponse<List<GoodsInfoResDto>> getGoodsInfo(@RequestBody GoodsInfoReqDto reqDto) {
        List<GoodsInfoResDto> goodsInfo = service.getGoodsInfo(reqDto);
        RestResponse<List<GoodsInfoResDto>> listRestResponse = RestResponse.buildSuccessResponse(goodsInfo);
        return listRestResponse;

    }

    @PostMapping("/query/goodsinfocount")
    @ApiOperation("统计商品池数据量")
    public RestResponse<List<GoodsInfoCountResDto>> getGoodsInfoCount(@RequestBody GoodsInfoCountReqDto reqDto) {
        List<GoodsInfoCountResDto> goodsInfoCount = service.getGoodsInfoCount(reqDto);
        RestResponse<List<GoodsInfoCountResDto>> listRestResponse = RestResponse.buildSuccessResponse(goodsInfoCount);
        return listRestResponse;

    }


}
