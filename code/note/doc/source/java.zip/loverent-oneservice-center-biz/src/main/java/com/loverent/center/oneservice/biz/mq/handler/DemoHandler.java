package com.loverent.center.oneservice.biz.mq.handler;


import com.loverent.center.oneservice.biz.dao.eo.DemoEo;
import com.loverent.common.helper.BeanHelper;
import org.springframework.stereotype.Component;
import org.springframework.transaction.annotation.Transactional;

import javax.annotation.Resource;

/**
 * MQ消息处理类示例
 *
 * @author yu.ce@foxmail.com
 * @version 1.0.0
 * @date  2019-11-25 17:35
 */
@Component
public class DemoHandler {
/*	@Resource
	private IDemoService demoService;

	@Transactional(rollbackFor = Exception.class)
	public DemoEo handler(DemoReqDto reqDto){
		DemoEo demoUserEo = new DemoEo();
		BeanHelper.copyProperties(demoUserEo , reqDto);
		demoService.saveOrUpdate(demoUserEo);
		return demoUserEo;
	}

	public void rollBackHandler(Long pkId){
		demoService.deleteById(pkId);
	}*/
}
