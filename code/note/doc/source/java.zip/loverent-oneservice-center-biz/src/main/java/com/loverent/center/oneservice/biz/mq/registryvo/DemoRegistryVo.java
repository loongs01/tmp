package com.loverent.center.oneservice.biz.mq.registryvo;

import com.loverent.starter.mq.config.SubscribeProperties;
import org.springframework.boot.context.properties.ConfigurationProperties;
import org.springframework.context.annotation.Configuration;

/**
 * 消息订阅关系配置示例
 *
 * @author yu.ce@foxmail.com
 * @version 1.0.0
 * @date  2019-11-27 14:10
 */
@Configuration
@ConfigurationProperties(prefix = "mq.demouser.subscribe.registryvo")
public class DemoRegistryVo extends SubscribeProperties {
	public DemoRegistryVo() {
		super();
	}
}
