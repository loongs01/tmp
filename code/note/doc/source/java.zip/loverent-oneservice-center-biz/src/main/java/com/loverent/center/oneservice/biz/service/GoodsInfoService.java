package com.loverent.center.oneservice.biz.service;

import com.loverent.center.oneservice.api.dto.request.GoodsInfoCountReqDto;
import com.loverent.center.oneservice.api.dto.request.GoodsInfoReqDto;

import com.loverent.center.oneservice.api.dto.response.GoodsInfoCountResDto;
import com.loverent.center.oneservice.api.dto.response.GoodsInfoResDto;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.service
 * @ClassName GoodsInfoService
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  13:35
 */
public interface GoodsInfoService {
    List<GoodsInfoResDto> getGoodsInfo(@RequestBody GoodsInfoReqDto reqDto);

    List<GoodsInfoCountResDto> getGoodsInfoCount(@RequestBody GoodsInfoCountReqDto reqDto);
}
