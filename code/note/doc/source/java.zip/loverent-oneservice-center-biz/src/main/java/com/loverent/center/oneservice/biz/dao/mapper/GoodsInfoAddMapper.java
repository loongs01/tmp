package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.GoodsInfoAddResDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.dao.mapper
 * @ClassName GoodsInfoMapper
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  13:36
 */
@Mapper
@Repository
public interface GoodsInfoAddMapper {


    List<GoodsInfoAddResDto> getGoodsInfoAdd(@Param("goodsCodeList") List<String> goodsCodeList
            , @Param("cycleDays1") Integer cycleDays1, @Param("cycleDays2") Integer cycleDays2, @Param("cycleDays3") Integer cycleDays3
            , @Param("weight1") Integer weight1, @Param("weight2") Integer weight2, @Param("weight3") Integer weight3
    );
}
