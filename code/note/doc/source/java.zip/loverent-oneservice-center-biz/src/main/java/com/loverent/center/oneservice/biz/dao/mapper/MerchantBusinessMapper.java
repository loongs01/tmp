package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.MerchantOrderRateRespDto;
import com.loverent.center.oneservice.api.dto.response.OptClassRespDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

/**
 * @author zhoutw
 * @date 2023年12月08日 9:15
 */
@Mapper
@Repository
public interface MerchantBusinessMapper  {

    MerchantOrderRateRespDto getOrderRate(@Param("merchantCode") String merchantCode,@Param("statDate") String statDate);

    List<MerchantOrderRateRespDto> getOrderRateBymerchantCodes(@Param("merchantCodes") List<String> merchantCodes,@Param("statDate") String statDate);

    String getStatTime(@Param("merchantCode") String merchantCode);



    List<OptClassRespDto>  getOptClass();
}
