package com.loverent.center.oneservice.biz.cache;

import com.loverent.center.oneservice.biz.dao.eo.DemoEo;
import com.loverent.redis.cache.service.IRedisCacheService;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * 缓存使用示例
 *
 * @author yu.ce@foxmail.com
 * @version 1.0.0
 * @date  2019-11-22 20:40
 */
@Component
public class DemoCache {
	@Resource
	private IRedisCacheService redisCacheService;

	public void setCache(DemoEo demoUserEo){
		redisCacheService.set(demoUserEo.getId().toString() ,  demoUserEo , 0);
	}

	public void getCache(String pkId){
		redisCacheService.get(pkId , DemoEo.class);
	}
}
