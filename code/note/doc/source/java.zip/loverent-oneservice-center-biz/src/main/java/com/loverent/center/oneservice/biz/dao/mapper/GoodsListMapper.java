package com.loverent.center.oneservice.biz.dao.mapper;


import com.loverent.center.oneservice.api.dto.response.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.math.BigInteger;
import java.util.List;

@Mapper
@Repository
public interface GoodsListMapper {
    List<GoodsFirstPageHostListResDto> getGoodsHotList(@Param("channelNo") String channelNo, @Param("catePageLv1Id") BigInteger catePageLv1Id,@Param("goodsCode") String goodsCode,@Param("goodsTitle") String goodsTitle,@Param("spuCode") String spuCode);

    List<GoodsFirstPageNewListResDto> getGoodsNewList(@Param("channelNo") String channelNo, @Param("catePageLv1Id") BigInteger catePageLv1Id,@Param("goodsCode") String goodsCode,@Param("goodsTitle") String goodsTitle,@Param("spuCode") String spuCode);

    List<GoodsFirstPagePriceReductionListResDto> getGoodsPriceReductionList(@Param("channelNo") String channelNo, @Param("catePageLv1Id") BigInteger catePageLv1Id,@Param("goodsCode") String goodsCode,@Param("goodsTitle") String goodsTitle,@Param("spuCode") String spuCode);

    List<GoodsOrderHotListResDto> getManualGoodsPageHotList(@Param("channelNo") String channelNo,@Param("goodsCode") List<String> goodsCode);

    List<GoodsOrderNewListResDto> getManualGoodsPageNewList(@Param("channelNo") String channelNo,@Param("goodsCode") List<String> goodsCode);

    List<GoodsOrderPriceReductionListResDto> getManualGoodsPagepriceReductionList(@Param("channelNo") String channelNo, @Param("goodsCode") List<String> goodsCode);


    List<GoodsFirstPageListCateResDto> getGoodsListCate(@Param("channelNo") String channelNo);

    List<GoodsFirstPageWaterfallListResDto>getWaterfallList(@Param("channelNo") String channelNo,@Param("listRk") Integer listRk, @Param("goodsCode") List<String> goodsListReqDto);

    List<GoodsRecommendListResDto> getNewListMoreRankGoodsCate(@Param("channelNo") String channelNo ,@Param("catePageLv1Id") List<String> catePageLv1Id);

    List<GoodsRecommendListResDto> getHotListMoreRankGoodsCate(@Param("channelNo") String channelNo ,@Param("catePageLv1Id") List<String> catePageLv1Id);

    List<GoodsRecommendListResDto> getPriceReductionListMoreRankGoodsCate(@Param("channelNo") String channelNo ,@Param("catePageLv1Id") List<String> catePageLv1Id);


    List<GoodsRecommendListGoodsReqDto> getNewListMoreRankGoods(@Param("channelNo") String channelNo ,@Param("catePageLv1Id") List<String> catePageLv1Id);

    List<GoodsRecommendListGoodsReqDto> getHotListMoreRankGoods(@Param("channelNo") String channelNo ,@Param("catePageLv1Id") List<String> catePageLv1Id);

    List<GoodsRecommendListGoodsReqDto> getPriceReductionListMoreRankGoods(@Param("channelNo") String channelNo ,@Param("catePageLv1Id") List<String> catePageLv1Id);



    List<BigDataRankGoodsTop50RespDto> geteWaterfallGoodsNewListInfo(@Param("channelNo") String channelNo,@Param("catePageLv1Id") List<Long> catePageLv1Id);

    List<BigDataRankGoodsTop50RespDto> geteWaterfallGoodsHotListInfo(@Param("channelNo") String channelNo,@Param("catePageLv1Id") List<Long> catePageLv1Id);

    List<BigDataRankGoodsTop50RespDto> geteWaterfallGoodsDropListInfo(@Param("channelNo") String channelNo,@Param("catePageLv1Id") List<Long> catePageLv1Id);





}
