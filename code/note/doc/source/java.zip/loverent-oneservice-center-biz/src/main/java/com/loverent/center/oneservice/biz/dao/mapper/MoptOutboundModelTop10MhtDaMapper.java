package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.MerchantBussinessMainModelRespDto;
import com.loverent.center.oneservice.api.dto.response.MerchantBussinessMainRiskRespDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;
@Mapper
@Repository
public interface MoptOutboundModelTop10MhtDaMapper {

    List<MerchantBussinessMainModelRespDto> getTop10ByMerchant(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate);
}
