package com.loverent.center.oneservice.biz.service;

import com.loverent.center.oneservice.api.dto.request.GoodsInfoAddReqDto;

import com.loverent.center.oneservice.api.dto.response.GoodsInfoAddResDto;

import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.service
 * @ClassName GoodsInfoService
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  13:35
 */
public interface GoodsInfoAddService {


    List<GoodsInfoAddResDto> getGoodsInfoAdd(@RequestBody GoodsInfoAddReqDto reqDto);
}
