package com.loverent.center.oneservice.biz.controller;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import com.loverent.center.oneservice.biz.service.MerchantListService;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/4/2 9:47
 */

@Slf4j
@Api("商户标榜单排名制器")
@ApiModel(description = "商户标榜单排名制器")
@RestController
@RequestMapping("/data/merchant")
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class MerchantListController {
    MerchantListService service;
    //商户明细数据
    @PostMapping("/query/merchantList")
    @ApiOperation("获取商户榜单数据")
    public RestResponse<ResultPager<MerchantListResDto>> getMerchantList(@RequestBody MerchantListReqDto reqDto){
        ResultPager<MerchantListResDto> merchantList = service.getMerchantList(reqDto);
        RestResponse<ResultPager<MerchantListResDto>> resultPagerRestResponse = RestResponse.buildSuccessResponse(merchantList);
        return resultPagerRestResponse;

    }
  //商户类目数据
    @PostMapping("/query/merchantCateList")
    @ApiOperation("获取商户类目数据")
    public RestResponse<List<MerchantListCateResDto>> getMerchantCateList(){
        List<MerchantListCateResDto> merchantCateList = service.getMerchantCateList();
        RestResponse<List<MerchantListCateResDto>> listRestResponse = RestResponse.buildSuccessResponse(merchantCateList);
        return listRestResponse;

    }

 //商详页返回商户排名数据
    @PostMapping("/query/merchantListRank")
    @ApiOperation("获取商户排名数据")
    public RestResponse<MerchantListResDto> getMerchantListRank(@RequestBody MerchantCodeReqDto reqDto){
        MerchantListResDto merchantListTop1 = service.getMerchantListTop1(reqDto);
        RestResponse<MerchantListResDto> merchantListResDtoRestResponse = RestResponse.buildSuccessResponse(merchantListTop1);
        return merchantListResDtoRestResponse;

    }

//c端店铺榜排名数据
    @PostMapping("/query/merchantCateTop1")
    @ApiOperation("获取商户榜单类目排名数据")
    public RestResponse<ResultPager<MerchantListTop3ResDto>> getMerchantCateTop1(@RequestBody MerchantCateListReqDto reqDto){
        ResultPager<MerchantListTop3ResDto> merchantCateTop1 = service.getMerchantCateTop1(reqDto);
        RestResponse<ResultPager<MerchantListTop3ResDto>> resultPagerRestResponse = RestResponse.buildSuccessResponse(merchantCateTop1);
        return resultPagerRestResponse;

    }


    //c端店铺榜排名数据
    @PostMapping("/query/merchantInfo")
    @ApiOperation("获取商户信息")
    public RestResponse<List<MerchantInfoResDto>> getMerchantInfo(@RequestBody MerchantInfoReqDto reqDto){
        List<MerchantInfoResDto> merchantInfo = service.getMerchantInfo(reqDto);
        RestResponse<List<MerchantInfoResDto>> resultPagerRestResponse = RestResponse.buildSuccessResponse(merchantInfo);
        return resultPagerRestResponse;

    }


    @PostMapping("/query/merchantGoodsInfo")
    @ApiOperation("获取商户商品信息")
    public RestResponse<List<MerchantGoodsNumRankResDto>> getMerchantGoodsInfo(@RequestBody MerchantInfoReqDto reqDto){
        List<MerchantGoodsNumRankResDto> merchantInfo = service.getMerchantGoodsInfo(reqDto);
        RestResponse<List<MerchantGoodsNumRankResDto>> resultPagerRestResponse = RestResponse.buildSuccessResponse(merchantInfo);
        return resultPagerRestResponse;

    }

    @PostMapping("/query/listTop50ByCateLv1Codes")
    @ApiOperation("根据一级类目编码列表获取前50店铺")
    RestResponse<List<BigDataRankShopTop50RespDto>> listTop50ByCatePageLv1IdRankTypes(@RequestBody BigDataRankShopTop50ReqpDto reqDto){
        List<BigDataRankShopTop50RespDto> merchantListRankInfo = service.getMerchantListRankInfo(reqDto);
        RestResponse<List<BigDataRankShopTop50RespDto>> listRestResponse = RestResponse.buildSuccessResponse(merchantListRankInfo);
        return listRestResponse;

    }

}
