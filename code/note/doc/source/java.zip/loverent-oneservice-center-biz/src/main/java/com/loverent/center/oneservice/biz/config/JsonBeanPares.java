package com.loverent.center.oneservice.biz.config;


import lombok.extern.slf4j.Slf4j;
import org.apache.commons.io.IOUtils;
import org.springframework.context.annotation.ClassPathScanningCandidateComponentProvider;
import org.springframework.context.annotation.Configuration;
import org.springframework.core.io.Resource;
import org.springframework.core.io.support.PathMatchingResourcePatternResolver;
import org.springframework.core.io.support.ResourcePatternResolver;
import org.springframework.util.ClassUtils;

import javax.annotation.PostConstruct;
import java.io.IOException;
import java.util.HashMap;
import java.util.Map;

@Configuration
@Slf4j
public class JsonBeanPares {

    private Map<String, String> map = new HashMap<>();

    /**
     * 预加载DSL语句
     */
    @PostConstruct
    public void initialization() {
        ClassPathScanningCandidateComponentProvider pathScanningCandidateComponentProvider = new ClassPathScanningCandidateComponentProvider(true);
        String packageSearchPath = "classpath*:" +
                ClassUtils.convertClassNameToResourcePath(pathScanningCandidateComponentProvider.getEnvironment().resolveRequiredPlaceholders("dsl")) + '/' +
                "**/*.json";

        ResourcePatternResolver resourcePatternResolver = new PathMatchingResourcePatternResolver();
        try{
            Resource[] resource = resourcePatternResolver.getResources(packageSearchPath);
            for(Resource r:resource){
                log.info("=========================spring 加载文件的方式,获取到文件:{}",r.getFilename());
                String fileName = r.getFilename();
                String[] realName = fileName.split("\\.");
                String jsonString = IOUtils.toString(r.getInputStream(),"UTF-8");
                map.put(realName[0],jsonString);
            }
        }catch (IOException e){
            log.debug("搜索文件读取失败,请检查文件",e);
        }
    }

    public String getBytesArray(String key) {
        return map.get(key);
    }

    public static void main(String[] args){
        new JsonBeanPares().initialization();

    }
}
