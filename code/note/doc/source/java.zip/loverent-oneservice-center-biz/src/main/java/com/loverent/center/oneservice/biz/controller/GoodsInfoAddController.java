package com.loverent.center.oneservice.biz.controller;

import com.loverent.center.oneservice.api.dto.request.GoodsInfoAddReqDto;

import com.loverent.center.oneservice.api.dto.response.GoodsInfoAddResDto;

import com.loverent.center.oneservice.biz.service.GoodsInfoAddService;
import com.loverent.common.rest.RestResponse;
import io.swagger.annotations.Api;
import io.swagger.annotations.ApiModel;
import io.swagger.annotations.ApiOperation;
import lombok.AllArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.controller
 * @ClassName GoodsInfoController
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  11:59
 */


@Slf4j
@Api("商品信息控制器")
@ApiModel(description = "商品信息控制器")
@RestController
@RequestMapping("/data/goods")
@AllArgsConstructor(onConstructor_ = {@Autowired})
public class GoodsInfoAddController {
    GoodsInfoAddService service;


    @PostMapping("/query/goodsinfoadd")
    @ApiOperation("获取手动新增商品明细数据")
    public RestResponse<List<GoodsInfoAddResDto>> getGoodsInfoAdd(@RequestBody GoodsInfoAddReqDto reqDto) {
        List<GoodsInfoAddResDto> goodsInfoAdd = service.getGoodsInfoAdd(reqDto);
        RestResponse<List<GoodsInfoAddResDto>> listRestResponse = RestResponse.buildSuccessResponse(goodsInfoAdd);
        return listRestResponse;

    }


}
