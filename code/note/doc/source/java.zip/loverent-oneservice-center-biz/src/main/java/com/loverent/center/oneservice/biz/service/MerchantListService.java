package com.loverent.center.oneservice.biz.service;

import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import org.springframework.web.bind.annotation.RequestBody;

import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/4/2 9:09
 */


public interface MerchantListService {

    ResultPager<MerchantListResDto> getMerchantList(@RequestBody MerchantListReqDto reqDto);

    List<MerchantListCateResDto> getMerchantCateList();

    MerchantListResDto getMerchantListTop1(@RequestBody MerchantCodeReqDto reqDto);

    ResultPager<MerchantListTop3ResDto> getMerchantCateTop1(@RequestBody MerchantCateListReqDto reqDto);

    List<MerchantInfoResDto> getMerchantInfo(@RequestBody MerchantInfoReqDto reqDto);

    List<MerchantGoodsNumRankResDto> getMerchantGoodsInfo(@RequestBody MerchantInfoReqDto reqDto);

    List<BigDataRankShopTop50RespDto> getMerchantListRankInfo(@RequestBody BigDataRankShopTop50ReqpDto reqDto);


}
