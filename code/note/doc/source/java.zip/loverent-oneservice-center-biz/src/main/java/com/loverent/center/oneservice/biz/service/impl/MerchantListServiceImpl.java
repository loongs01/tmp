package com.loverent.center.oneservice.biz.service.impl;

import com.github.pagehelper.PageHelper;
import com.github.pagehelper.PageInfo;
import com.loverent.center.oneservice.api.dto.request.*;
import com.loverent.center.oneservice.api.dto.response.*;
import com.loverent.center.oneservice.biz.dao.mapper.MerchantListMapper;
import com.loverent.center.oneservice.biz.service.MerchantListService;
import jodd.util.CollectionUtil;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

/**
 * @Auther:qiukai
 * @Date:2024/4/2 9:08
 */

@Service
@Slf4j
public class MerchantListServiceImpl implements MerchantListService {

    @Autowired
    MerchantListMapper merchantListMapper;

    @Override
    public ResultPager<MerchantListResDto> getMerchantList(MerchantListReqDto reqDto) {
        PageInfo<MerchantListResDto> pageInfo = PageHelper.startPage(reqDto.getCurrPage(), reqDto.getPageSize()).doSelectPageInfo(()
                -> merchantListMapper.getMerchantList(reqDto.getCateLv1Code(),reqDto.getMerchantCode()));
        if (pageInfo != null) {
            List<MerchantListResDto> list = pageInfo.getList();
            ArrayList<String> merchantCodes = new ArrayList<>();
            if (list != null && list.size() > 0) {
                for (int i = 0; i < list.size(); i++) {
                    String merchantCode = list.get(i).getMerchantCode();
                    merchantCodes.add(merchantCode);
                }
                List<MerchantGoodsNumRankResDto> merchantGoodsNumRankList = merchantListMapper.getMerchantGoodsNumRankList(merchantCodes);
                Map<String, List<MerchantGoodsNumRankResDto>> collect = merchantGoodsNumRankList.stream().collect(Collectors.groupingBy(MerchantGoodsNumRankResDto::getMerchantCode));
                if (list != null && list.size() > 0) {
                    for (int i = 0; i < list.size(); i++) {
                        String merchantCode = list.get(i).getMerchantCode();
                        list.get(i).setGoodsInfo(collect.get(merchantCode));

                    }
                }

            }

        }
        return new ResultPager<>((int) pageInfo.getTotal(), reqDto.getCurrPage(), reqDto.getPageSize(), pageInfo.getList());

    }

    @Override
    public List<MerchantListCateResDto> getMerchantCateList() {
        return merchantListMapper.getMerchantCateList();

    }


    @Override
    public MerchantListResDto getMerchantListTop1(MerchantCodeReqDto reqDto) {
        return merchantListMapper.getMerchantListTop1(reqDto.getMerchantCode());
    }

    @Override
    public ResultPager<MerchantListTop3ResDto> getMerchantCateTop1(MerchantCateListReqDto reqDto) {

        PageInfo<MerchantListTop3ResDto> pageInfo = PageHelper.startPage(reqDto.getCurrPage(), reqDto.getPageSize()).doSelectPageInfo(()
                -> merchantListMapper.getMerchantCateTop1());
        if (pageInfo != null) {
            List<MerchantListTop3ResDto> list = pageInfo.getList();
            ArrayList<String> cateLv1Codes = new ArrayList<>();
            if (list != null && list.size() > 0) {
                for (int i = 0; i < list.size(); i++) {
                    String CateLv1Code = list.get(i).getCateLv1Code();
                    cateLv1Codes.add(CateLv1Code);
                }
                List<MerchantListResDto> merchantGoodsNumRankList = merchantListMapper.getMerchantRankList(cateLv1Codes);
                Map<String, List<MerchantListResDto>> collect = merchantGoodsNumRankList.stream().collect(Collectors.groupingBy(MerchantListResDto::getCateLv1Code));
                if (list != null && list.size() > 0) {
                    for (int i = 0; i < list.size(); i++) {
                        String merchantCode = list.get(i).getCateLv1Code();
                        list.get(i).setMerchantListResDto(collect.get(merchantCode));

                    }
                }

            }

        }

        return new ResultPager<>((int) pageInfo.getTotal(), reqDto.getCurrPage(), reqDto.getPageSize(), pageInfo.getList());
    }

    @Override
    public List<MerchantInfoResDto> getMerchantInfo(MerchantInfoReqDto reqDto) {
        return merchantListMapper.getMerchantInfo(reqDto.getMerchantInfo());
    }

    @Override
    public List<MerchantGoodsNumRankResDto> getMerchantGoodsInfo(MerchantInfoReqDto reqDto) {
        return merchantListMapper.getMerchantGoodsNumRankList(reqDto.getMerchantInfo());
    }

    @Override
    public List<BigDataRankShopTop50RespDto> getMerchantListRankInfo(BigDataRankShopTop50ReqpDto reqDto) {
        List<BigDataRankShopTop50RespDto> merchantListRankInfo = merchantListMapper.getMerchantListRankInfo(reqDto.getCateLv1Codes());
        return merchantListRankInfo;
    }
}