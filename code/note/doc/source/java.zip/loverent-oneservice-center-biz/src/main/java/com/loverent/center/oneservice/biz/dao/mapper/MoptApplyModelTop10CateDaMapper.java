package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.MerchantBussinessMainModelRespDto;
import com.loverent.center.oneservice.api.dto.response.MerchantBussinessModelRespDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MoptApplyModelTop10CateDaMapper {

    List<MerchantBussinessModelRespDto> getTop10Total(
            @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate
            , @Param("optClassCode") String optClassCode, @Param("optClassName") String optClassName
    );
}
