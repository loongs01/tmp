package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.response.MerchantBussinessMainClassRespDto;
import com.loverent.center.oneservice.api.dto.response.MerchantBussinessMainRiskRespDto;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

@Mapper
@Repository
public interface MoptUsrRiskMhtTdMapper {

    List<MerchantBussinessMainRiskRespDto> getRiskRate(@Param("merchantCode") String merchantCode
            , @Param("statStartDate") String statStartDate, @Param("statEndDate") String statEndDate);



}
