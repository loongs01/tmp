package com.loverent.center.oneservice.biz.service.impl;

import com.alibaba.excel.util.CollectionUtils;
import com.loverent.center.oneservice.api.dto.request.GoodsInfoCountReqDto;
import com.loverent.center.oneservice.api.dto.request.GoodsInfoReqDto;
import com.loverent.center.oneservice.api.dto.response.GoodsInfoCountResDto;
import com.loverent.center.oneservice.api.dto.response.GoodsInfoResDto;
import com.loverent.center.oneservice.biz.dao.mapper.GoodsInfoMapper;
import com.loverent.center.oneservice.biz.service.GoodsInfoService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.stream.Collectors;

/**
 * @BelongProject: loverent-oneservice-center
 * @BelongPackage: com.loverent.center.oneservice.biz.service.impl
 * @ClassName GoodsInfoServiceImpl
 * @Author: lichaozhong
 * @CreateTime: 2024-05-07  14:54
 */
@Service
@Slf4j
public class GoodsInfoServiceImpl implements GoodsInfoService {

    @Autowired
    GoodsInfoMapper goodsInfoMapper;

    @Override
    public List<GoodsInfoResDto> getGoodsInfo(GoodsInfoReqDto reqDto) {
        //Integer i = new Integer(1);


        Integer cycleDays1 = 0;
        Integer cycleDays2 = 0;
        Integer cycleDays3 = 0;
        Integer weight1 = 0;
        Integer weight2 = 0;
        Integer weight3 = 0;
        if (reqDto.getSortingRuleList() != null) {
            if (reqDto.getSortingRuleList().size() == 1) {
                cycleDays1 = reqDto.getSortingRuleList().get(0).getCycleDays();
                weight1 = reqDto.getSortingRuleList().get(0).getWeight();
            } else if (reqDto.getSortingRuleList().size() == 2) {
                cycleDays1 = reqDto.getSortingRuleList().get(0).getCycleDays();
                weight1 = reqDto.getSortingRuleList().get(0).getWeight();
                cycleDays2 = reqDto.getSortingRuleList().get(1).getCycleDays();
                weight2 = reqDto.getSortingRuleList().get(1).getWeight();

            } else if (reqDto.getSortingRuleList().size() == 3) {
                cycleDays1 = reqDto.getSortingRuleList().get(0).getCycleDays();
                weight1 = reqDto.getSortingRuleList().get(0).getWeight();
                cycleDays2 = reqDto.getSortingRuleList().get(1).getCycleDays();
                weight2 = reqDto.getSortingRuleList().get(1).getWeight();
                cycleDays3 = reqDto.getSortingRuleList().get(2).getCycleDays();
                weight3 = reqDto.getSortingRuleList().get(2).getWeight();

            } else {
                System.out.println(reqDto.getSortingRuleList());
            }
        }
//        String dateTime = GetSystemTime.getTime();

        if (!CollectionUtils.isEmpty(reqDto.getMerchantCodeList())) {
            List<Integer> merchantTypeList = reqDto.getMerchantTypeList();
            if (!CollectionUtils.isEmpty(merchantTypeList)) {
                List<Integer> newTypeList = merchantTypeList.stream().filter(type -> type != 2).collect(Collectors.toList());
                reqDto.setMerchantTypeList(newTypeList);
            }
        }

        return goodsInfoMapper.getGoodsInfo(reqDto.getTypeCodeList(), reqDto.getBrandCodeList(), reqDto.getModelCodeList()
                , reqDto.getMerchantTypeList(), reqDto.getMerchantCodeList(), reqDto.getLeaseMoldCodeList(), reqDto.getNewConfigIdList(), reqDto.getLeaseTermTypeList()
                , reqDto.getDiscountTypeList()
                , cycleDays1, cycleDays2, cycleDays3
                , weight1, weight2, weight3
        );
    }

    @Override
    public List<GoodsInfoCountResDto> getGoodsInfoCount(GoodsInfoCountReqDto reqDto) {

//        String dateTime = GetSystemTime.getTime();
        if (!CollectionUtils.isEmpty(reqDto.getMerchantCodeList())) {
            List<Integer> merchantTypeList = reqDto.getMerchantTypeList();
            if (!CollectionUtils.isEmpty(merchantTypeList)) {
                List<Integer> newTypeList = merchantTypeList.stream().filter(type -> type != 2).collect(Collectors.toList());
                reqDto.setMerchantTypeList(newTypeList);
            }
        }


        return goodsInfoMapper.getGoodsInfoCount(reqDto.getTypeCodeList(), reqDto.getBrandCodeList(), reqDto.getModelCodeList()
                , reqDto.getMerchantTypeList(), reqDto.getMerchantCodeList(), reqDto.getLeaseMoldCodeList(), reqDto.getNewConfigIdList(), reqDto.getLeaseTermTypeList()
                , reqDto.getDiscountTypeList()
        );
    }
}
