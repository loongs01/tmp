package com.loverent.center.oneservice.biz.mq.processor;

import com.alibaba.fastjson.JSON;
import com.loverent.center.oneservice.biz.cache.DemoCache;
import com.loverent.center.oneservice.biz.dao.eo.DemoEo;
import com.loverent.center.oneservice.biz.mq.handler.DemoHandler;
import com.loverent.common.rest.MessageResponse;
import com.loverent.common.vo.MessageVo;
import com.loverent.framework.log.LoggerFactory;
import com.loverent.mq.annotation.MQSubscribe;
import com.loverent.mq.api.IMessageProcessor;
import org.apache.commons.lang3.exception.ExceptionUtils;
import org.slf4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import javax.annotation.Resource;

/**
 * MQ consumer订阅示例
 * 2种示例,一种使用直接使用常量,一种使用${}读取配置文件,或者nacos配置
 * 严禁将有数据库事务相关的处理放在Processor类中,请放在Handler中
 *
 * @author yu.ce@foxmail.com
 *
 * @version 1.0.0
 * @date  2019-11-25 17:03
 */
//@MQSubscribe(topic = MQConstant.DEMO_USER_TOPIC, tag = MQConstant.DEMO_USER_TAG ,consumer = MQConstant.DEMO_USER_CONSUMER)
/*@Component
@MQSubscribe(topic = "${mq.demouser.subscribe.registryvo.topic}", tag = "${mq.demouser.subscribe.registryvo.tag}" ,
		consumer = "${mq.demouser.subscribe.registryvo.consumer}")

public class DemoProcessor implements IMessageProcessor<MessageVo> {
	*/
/*private static final Logger loger = LoggerFactory.getLogger(DemoProcessor.class);
	@Resource
	private DemoHandler demoHandler;

	@Autowired
	private DemoCache demoCache;

	*//*
*/
/**
	 * 处理消息
	 *
	 * @param messageVo
	 * @return
	 *//*
*/
/*
	@Override
	public MessageResponse process(MessageVo messageVo) {
		loger.info("Subscribe MQ Message:{}" , JSON.toJSONString(messageVo));
		String msgContent = messageVo.getMsgContent();
		DemoReqDto reqDto = JSON.parseObject(msgContent , DemoReqDto.class);
		DemoEo demoUserEo = null;
		boolean rollBack = false;
		try {
			demoUserEo = demoHandler.handler(reqDto);
		} catch (Exception e) {
			loger.error(ExceptionUtils.getStackTrace(e));
			return MessageResponse.ERROR;
		}

		try {
			demoCache.setCache(demoUserEo);
			return MessageResponse.SUCCESS;
		}catch (Exception e){
			demoHandler.rollBackHandler(demoUserEo.getId());
			return MessageResponse.ERROR;
		}
	}*//*

}
*/
