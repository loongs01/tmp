package com.loverent.center.oneservice.biz.dao.mapper;

import com.loverent.center.oneservice.api.dto.request.MerchantInfoReqDto;
import com.loverent.center.oneservice.api.dto.request.MerchantListReqDto;
import com.loverent.center.oneservice.api.dto.response.*;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import java.util.List;

/**
 * @Auther:qiukai
 * @Date:2024/4/1 19:30
 */

@Mapper
@Repository
public interface MerchantListMapper {
    List<MerchantListResDto> getMerchantList(@Param("cateLv1Code") String cateLv1Code,@Param("merchantCode") String merchantCode);

    List<MerchantListCateResDto> getMerchantCateList();

    MerchantListResDto getMerchantListTop1(@Param("merchantCode") String merchantCode);

    List<MerchantListTop3ResDto> getMerchantCateTop1( );

    List<MerchantGoodsNumRankResDto> getMerchantGoodsNumRankList(@Param("merchantCodes") List<String> merchantCodes);

    List<MerchantListResDto> getMerchantRankList(@Param("cateLv1Codes") List<String> cateLv1Codes);

    List<MerchantInfoResDto> getMerchantInfo(@Param("merchantInfo") List<String> merchantInfo);

    List<BigDataRankShopTop50RespDto> getMerchantListRankInfo(@Param("cateLv1Code") List<String> cateLv1Code );


}
