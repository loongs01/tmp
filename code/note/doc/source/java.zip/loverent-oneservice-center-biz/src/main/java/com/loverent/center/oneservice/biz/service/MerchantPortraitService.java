package com.loverent.center.oneservice.biz.service;

import com.loverent.center.oneservice.api.dto.response.MerchantPortraitRespDto;

import java.util.List;

public interface MerchantPortraitService {

    /**
     * 根据店铺列表商家画像
     * @param
     * @return
     */
    public List<MerchantPortraitRespDto> batchQueryPortraitMerge(List<String> merchantCodeList);
}
